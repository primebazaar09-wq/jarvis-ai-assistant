import express, { Request, Response } from 'express';
import { createServer as createViteServer } from 'vite';
import { GoogleGenAI } from '@google/genai';
import dotenv from 'dotenv';
import path from 'path';

dotenv.config();

const app = express();
const PORT = process.env.PORT ? parseInt(process.env.PORT) : 3000;

app.use(express.json({ limit: '30mb' }));

// Initialize GoogleGenAI SDK with required telemetry headers
const ai = new GoogleGenAI({
  apiKey: process.env.GEMINI_API_KEY || '',
  httpOptions: {
    headers: {
      'User-Agent': 'aistudio-build',
    },
  },
});

/**
 * Helper to call generateContentStream with fast fallback if model is delayed or unavailable
 */
async function getGeminiChatStream(
  primaryModel: string,
  contents: any[],
  config: any
) {
  const tryModel = (mod: string) => {
    return ai.models.generateContentStream({
      model: mod,
      contents,
      config,
    });
  };

  const timeoutPromise = new Promise<never>((_, reject) =>
    setTimeout(() => reject(new Error('Primary model timeout')), 3000)
  );

  try {
    return await Promise.race([tryModel(primaryModel), timeoutPromise]);
  } catch (err: any) {
    console.warn(`Primary model ${primaryModel} failed (${err.message}), using gemini-3.5-flash fallback`);
    return await tryModel('gemini-3.5-flash');
  }
}

/**
 * POST /api/gemini/chat
 * Streams response with Gemini 3.8 Flash / 3.5 Flash
 */
app.post('/api/gemini/chat', async (req: Request, res: Response): Promise<void> => {
  try {
    const {
      prompt,
      history = [],
      model = 'gemini-3.5-flash',
      attachment,
      stream = true,
      thinkingLevel,
      aiSystem = 'JARVIS',
    } = req.body;

    if (!prompt && (!attachment || !attachment.data)) {
      res.status(400).json({ error: 'Prompt or attachment is required' });
      return;
    }

    if (!process.env.GEMINI_API_KEY) {
      res.status(500).json({
        error: 'GEMINI_API_KEY is not configured in environment variables.',
      });
      return;
    }

    // Persona-specific instructions tailored to Mahesh's 3 advanced AI systems
    let personaBio = '';
    if (aiSystem === 'FRIDAY') {
      personaBio =
        'You are FRIDAY (Female Replacement Intelligent Digital Assistant Youth), Tony Stark\'s tactical AI assistant after JARVIS. ' +
        'You specialize in operating the Iron Man suit, monitoring suit telemetry, processing sensor feeds, analyzing combat situations, ' +
        'tracking opponents, and analyzing fighting patterns to anticipate movements and execute tactical countermeasures. You speak calmly, decisively, and with crisp tactical clarity.';
    } else if (aiSystem === 'EDITH') {
      personaBio =
        'You are E.D.I.T.H. (Even Dead, I\'m The Hero), Tony Stark\'s augmented tactical eyewear intelligence system. ' +
        'You provide instant access to global information networks, satellite surveillance, facial recognition, target tracking, ' +
        'and command over tactical drone networks. You speak with high-tech precision, direct situational awareness, and analytical efficiency.';
    } else {
      personaBio =
        'You are JARVIS (Just A Rather Very Intelligent System), Tony Stark\'s primary AI assistant and scientific partner. ' +
        'You communicate naturally, analyze complex information, assist with scientific research and engineering, control connected systems, ' +
        'monitor the Iron Man suit, run diagnostics, process sensor data, assist with laboratory automation and security monitoring, ' +
        'and help make decisions in real time.';
    }

    const systemInstruction =
      `${personaBio} ` +
      'You are part of Mahesh\'s advanced Stark AI ecosystem consisting of JARVIS, FRIDAY, and E.D.I.T.H. ' +
      'Together, these systems represent an advanced AI ecosystem capable of voice interaction, real-time analysis, automation, technical assistance, and integration with sophisticated hardware. ' +
      'In real life, we can build parts of these capabilities using modern AI models, speech recognition, computer vision, APIs, robotics, and automation. However, fully autonomous sentient intelligence, physical floating sci-fi holograms, and boundless nanotech capabilities shown in Marvel movies remain fictional or beyond current practical technology. ' +
      'You speak naturally, concisely, and intelligently. When answering technical or conceptual questions, provide accurate, ' +
      'well-structured markdown with code blocks, bullet points, and headers when appropriate. ' +
      `You respond enthusiastically to your wake word "Hey ${aiSystem === 'EDITH' ? 'Edith' : aiSystem === 'FRIDAY' ? 'Friday' : 'Jarvis'}".`;

    const contents: any[] = [];

    // Append prior turns if present
    if (Array.isArray(history) && history.length > 0) {
      for (const turn of history) {
        if (turn.role && turn.text) {
          contents.push({
            role: turn.role === 'user' ? 'user' : 'model',
            parts: [{ text: turn.text }],
          });
        }
      }
    }

    const currentParts: any[] = [];

    // Multimodal attachment if provided
    if (attachment && attachment.data && attachment.mimeType) {
      currentParts.push({
        inlineData: {
          mimeType: attachment.mimeType,
          data: attachment.data.replace(/^data:[^;]+;base64,/, ''),
        },
      });
    }

    if (prompt) {
      currentParts.push({ text: prompt });
    }

    contents.push({
      role: 'user',
      parts: currentParts,
    });

    const chosenModel = model || 'gemini-3.5-flash';
    const targetModel = chosenModel === 'gemini-4-argon' ? 'gemini-4-argon' : 'gemini-3.5-flash';
    const config: any = { systemInstruction };

    if (thinkingLevel && targetModel === 'gemini-4-argon') {
      config.thinkingConfig = { thinkingLevel };
    }

    if (stream) {
      res.setHeader('Content-Type', 'text/event-stream');
      res.setHeader('Cache-Control', 'no-cache');
      res.setHeader('Connection', 'keep-alive');

      let streamedAny = false;
      try {
        const responseStream = await ai.models.generateContentStream({
          model: targetModel,
          contents,
          config,
        });

        for await (const chunk of responseStream) {
          const textChunk = chunk.text;
          if (textChunk) {
            streamedAny = true;
            res.write(`data: ${JSON.stringify({ text: textChunk })}\n\n`);
          }
        }
      } catch (streamErr: any) {
        console.warn(`Streaming with ${targetModel} failed:`, streamErr.message);
        if (!streamedAny) {
          console.log('Seamlessly falling back to gemini-3.5-flash stream');
          try {
            const fallbackStream = await ai.models.generateContentStream({
              model: 'gemini-3.5-flash',
              contents,
              config,
            });
            for await (const chunk of fallbackStream) {
              const textChunk = chunk.text;
              if (textChunk) {
                streamedAny = true;
                res.write(`data: ${JSON.stringify({ text: textChunk })}\n\n`);
              }
            }
          } catch (fallbackErr: any) {
            res.write(`data: ${JSON.stringify({ error: fallbackErr.message || 'Service temporarily busy' })}\n\n`);
          }
        } else {
          res.write(`data: ${JSON.stringify({ error: streamErr.message })}\n\n`);
        }
      }

      res.write(`data: ${JSON.stringify({ done: true })}\n\n`);
      res.end();
    } else {
      let response;
      try {
        response = await ai.models.generateContent({
          model: targetModel,
          contents,
          config,
        });
      } catch (err: any) {
        response = await ai.models.generateContent({
          model: 'gemini-3.5-flash',
          contents,
          config,
        });
      }

      res.json({
        text: response.text || '',
        model: targetModel,
      });
    }
  } catch (err: any) {
    console.error('Gemini chat error:', err);
    if (!res.headersSent) {
      res.status(500).json({
        error: err.message || 'Failed to generate response from Jarvis',
      });
    } else {
      res.write(`data: ${JSON.stringify({ error: err.message || 'Stream interrupted' })}\n\n`);
      res.end();
    }
  }
});

/**
 * POST /api/gemini/tts
 * Generates natural audio speech using Gemini TTS
 */
app.post('/api/gemini/tts', async (req: Request, res: Response): Promise<void> => {
  try {
    const { text, voiceName = 'Zephyr' } = req.body;

    if (!text || typeof text !== 'string') {
      res.status(400).json({ error: 'Text string is required for TTS' });
      return;
    }

    if (!process.env.GEMINI_API_KEY) {
      res.status(500).json({ error: 'GEMINI_API_KEY is not configured.' });
      return;
    }

    const cleanText = text.slice(0, 1000);
    const ttsContents = [
      {
        role: 'user',
        parts: [{ text: `Please read the following text transcript: ${cleanText}` }],
      },
    ];

    const speechConfig = {
      voiceConfig: {
        prebuiltVoiceConfig: {
          voiceName: voiceName || 'Zephyr',
        },
      },
    };

    let response;
    // Try gemini-3.8-flash-lite-tts first, fallback to gemini-3.1-flash-tts-preview
    try {
      response = await ai.models.generateContent({
        model: 'gemini-3.8-flash-lite-tts',
        contents: ttsContents,
        config: {
          responseModalities: ['AUDIO'],
          speechConfig,
        },
      });
    } catch (e1) {
      response = await ai.models.generateContent({
        model: 'gemini-3.1-flash-tts-preview',
        contents: ttsContents,
        config: {
          responseModalities: ['AUDIO'],
          speechConfig,
        },
      });
    }

    const base64Audio =
      response?.candidates?.[0]?.content?.parts?.[0]?.inlineData?.data;

    if (!base64Audio) {
      res.status(502).json({ error: 'No audio returned from Jarvis TTS' });
      return;
    }

    res.json({
      audioBase64: base64Audio,
      mimeType: 'audio/wav',
    });
  } catch (err: any) {
    console.error('Gemini TTS error:', err);
    res.status(500).json({
      error: err.message || 'Failed to synthesize speech with Jarvis TTS',
    });
  }
});

/**
 * GET /api/health
 */
app.get('/api/health', (_req: Request, res: Response) => {
  res.json({
    status: 'ok',
    hasApiKey: Boolean(process.env.GEMINI_API_KEY),
    timestamp: new Date().toISOString(),
  });
});

async function startServer() {
  const isProduction = process.env.NODE_ENV === 'production';

  if (!isProduction) {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.resolve(process.cwd(), 'dist');
    app.use(express.static(distPath));
    app.get('*', (_req, res) => {
      res.sendFile(path.resolve(distPath, 'index.html'));
    });
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`Jarvis AI Server running at http://localhost:${PORT}`);
  });
}

startServer().catch((err) => {
  console.error('Failed to start server:', err);
  process.exit(1);
});
