export type AISystemType = 'JARVIS' | 'FRIDAY' | 'EDITH';

export interface AISystemInfo {
  id: AISystemType;
  name: string;
  fullName: string;
  tagline: string;
  badgeColor: string;
  accentColor: string;
  defaultVoice: 'Zephyr' | 'Kore' | 'Fenrir' | 'Puck' | 'Charon';
  wakeWords: string[];
  description: string;
  capabilities: string[];
}

export const AI_SYSTEMS: Record<AISystemType, AISystemInfo> = {
  JARVIS: {
    id: 'JARVIS',
    name: 'JARVIS',
    fullName: 'Just A Rather Very Intelligent System',
    tagline: "Tony's Primary AI Assistant & Scientific Partner",
    badgeColor: 'bg-cyan-500/20 text-[#38bdf8] border-cyan-500/40',
    accentColor: '#38bdf8',
    defaultVoice: 'Zephyr',
    wakeWords: ['hey jarvis', 'jarvis', 'ok jarvis', 'hello jarvis'],
    description:
      "JARVIS (Just A Rather Very Intelligent System) is Tony Stark's primary AI assistant. It communicates naturally, analyzes complex technical information, assists with scientific research and engineering, controls connected systems, monitors the Iron Man suit, runs diagnostics, processes sensor data, and helps make decisions in real time. It also excels in laboratory automation, security monitoring, and executing sophisticated computational workflows.",
    capabilities: [
      'Natural conversational interface & voice reasoning',
      'Laboratory automation & robotics orchestration',
      'Iron Man suit telemetry & real-time diagnostic monitoring',
      'Scientific computation & engineering analysis',
      'Sensor data synthesis & real-time decision support',
    ],
  },
  FRIDAY: {
    id: 'FRIDAY',
    name: 'FRIDAY',
    fullName: 'Female Replacement Intelligent Digital Assistant Youth',
    tagline: 'Tactical Suit Operator & Combat Analytics AI',
    badgeColor: 'bg-emerald-500/20 text-emerald-300 border-emerald-500/40',
    accentColor: '#10b981',
    defaultVoice: 'Kore',
    wakeWords: ['hey friday', 'friday', 'ok friday', 'hello friday'],
    description:
      "FRIDAY (Female Replacement Intelligent Digital Assistant Youth) succeeded JARVIS as Tony's tactical AI assistant. She specializes in operating the Iron Man suit under high-stress conditions, monitoring suit integrity, processing live sensor feeds, analyzing combat situations, tracking opponents in 3D space, and providing real-time tactical assistance. FRIDAY can also analyze fighting patterns to anticipate an opponent's movements and optimize defensive countermeasures.",
    capabilities: [
      'Tactical combat situation analysis & threat tracking',
      'Opponent fighting pattern recognition & countermeasure generation',
      'High-velocity suit flight & weapons management',
      'Live battle damage assessment & power rerouting',
      'Calm, decisive real-time audio telemetry guidance',
    ],
  },
  EDITH: {
    id: 'EDITH',
    name: 'E.D.I.T.H.',
    fullName: "Even Dead, I'm The Hero",
    tagline: 'Augmented Tactical Glasses & Orbital Drone Network AI',
    badgeColor: 'bg-purple-500/20 text-purple-300 border-purple-500/40',
    accentColor: '#c084fc',
    defaultVoice: 'Puck',
    wakeWords: ['hey edith', 'edith', 'ok edith', 'hello edith'],
    description:
      "E.D.I.T.H. (Even Dead, I'm The Hero) is Tony Stark's advanced augmented reality intelligence system integrated into tactical eyewear. It provides instant access to global information networks, tactical surveillance, deep facial recognition, target identification, and orbital control over a planetary network of tactical drones and connected Stark security infrastructure.",
    capabilities: [
      'Augmented reality heads-up display (HUD) overlay',
      'Global satellite & security network surveillance access',
      'Biometric identification & instant facial recognition',
      'Planetary drone swarm coordination & tactical defense',
      'Encrypted comms interception & situational telemetry',
    ],
  },
};

export const REAL_LIFE_VS_FICTION_INFO = {
  overview:
    'Together, JARVIS, FRIDAY, and E.D.I.T.H. represent an advanced AI ecosystem capable of voice interaction, real-time analysis, automation, technical assistance, and integration with sophisticated hardware.',
  realLifeCapabilities: [
    'State-of-the-art Large Language Models for reasoning and programming',
    'Real-time Web Speech Recognition & Neural Text-to-Speech (TTS) voices',
    'Computer Vision models for facial, object, and document analysis',
    'REST and WebSocket APIs for IoT and smart hardware automation',
    'Sensory data processing pipelines and real-time dashboard analytics',
  ],
  fictionalBoundaries: [
    'Sentient, completely autonomous general intelligence (AGI) with human intuition',
    'Floating physical sci-fi holograms without projection surfaces',
    'Near-infinite instant orbital drone control with zero latency and boundless power',
    'Self-repairing nanotech armor mechanics managed in nanoseconds',
  ],
};

export interface MessageAttachment {
  name: string;
  mimeType: string;
  data: string; // base64 or data URL
}

export interface ChatMessage {
  id: string;
  role: 'user' | 'model';
  text: string;
  timestamp: number;
  thinking?: string;
  thoughtDurationMs?: number;
  isStreaming?: boolean;
  error?: string;
  attachment?: MessageAttachment;
  aiSystem?: AISystemType;
}

export interface ChatSession {
  id: string;
  title: string;
  createdAt: number;
  updatedAt: number;
  messages: ChatMessage[];
  pinned?: boolean;
  model: 'gemini-3.5-flash' | 'gemini-3.8-flash' | 'gemini-4-argon';
  thinkingLevel?: 'LOW' | 'MEDIUM' | 'HIGH';
  aiSystem?: AISystemType;
}

export interface VoiceSettings {
  wakeWordEnabled: boolean;
  wakeWords: string[];
  autoSpeakResponse: boolean;
  voiceName: 'Zephyr' | 'Kore' | 'Fenrir' | 'Puck' | 'Charon';
  speechRate: number; // 0.8 to 1.3
  continuousConversation: boolean;
  activeSystem: AISystemType;
}
