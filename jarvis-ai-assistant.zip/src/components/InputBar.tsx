import React, { useRef, useEffect } from 'react';
import {
  ArrowUp,
  Square,
  Paperclip,
  Mic,
  MicOff,
  Radio,
  X,
  Sparkles,
} from 'lucide-react';
import { MessageAttachment } from '../types';

interface InputBarProps {
  prompt: string;
  onChangePrompt: (val: string) => void;
  onSubmit: () => void;
  isLoading: boolean;
  onStop: () => void;
  attachment: MessageAttachment | null;
  onSelectAttachment: (attachment: MessageAttachment | null) => void;
  isListening: boolean;
  isAwake: boolean;
  audioLevel?: number;
  onToggleMic: () => void;
  onOpenLiveVoice: () => void;
}

export const InputBar: React.FC<InputBarProps> = ({
  prompt,
  onChangePrompt,
  onSubmit,
  isLoading,
  onStop,
  attachment,
  onSelectAttachment,
  isListening,
  isAwake,
  audioLevel = 0,
  onToggleMic,
  onOpenLiveVoice,
}) => {
  const textareaRef = useRef<HTMLTextAreaElement>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);

  // Auto-resize textarea
  useEffect(() => {
    if (textareaRef.current) {
      textareaRef.current.style.height = 'auto';
      textareaRef.current.style.height = `${Math.min(
        textareaRef.current.scrollHeight,
        180
      )}px`;
    }
  }, [prompt]);

  const handleKeyDown = (e: React.KeyboardEvent<HTMLTextAreaElement>) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      if (!isLoading && (prompt.trim() || attachment)) {
        onSubmit();
      }
    }
  };

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = () => {
      const result = reader.result as string;
      onSelectAttachment({
        name: file.name,
        mimeType: file.type || 'image/jpeg',
        data: result,
      });
    };
    reader.readAsDataURL(file);
    e.target.value = '';
  };

  const canSubmit = Boolean(prompt.trim() || attachment) && !isLoading;

  return (
    <div className="w-full max-w-4xl mx-auto px-4 pb-4 pt-2">
      <div
        className={`relative flex flex-col rounded-3xl bg-[#1e1f20] border transition-all duration-300 shadow-xl ${
          isAwake
            ? 'border-cyan-400 ring-2 ring-cyan-500/40 shadow-cyan-500/10'
            : 'border-[#3c4043]/70 focus-within:border-cyan-500/60'
        }`}
      >
        {/* Attachment Preview */}
        {attachment && (
          <div className="px-4 pt-3 flex items-center gap-2">
            <div className="relative group rounded-xl overflow-hidden border border-[#3c4043] bg-[#282a2c] flex items-center gap-2 p-1.5 pr-3 max-w-xs">
              {attachment.mimeType.startsWith('image/') ? (
                <img
                  src={attachment.data}
                  alt={attachment.name}
                  className="w-10 h-10 object-cover rounded-lg"
                />
              ) : (
                <Paperclip className="w-5 h-5 text-[#38bdf8] ml-2" />
              )}
              <span className="text-xs text-[#e3e3e3] truncate max-w-[140px]">
                {attachment.name}
              </span>
              <button
                onClick={() => onSelectAttachment(null)}
                className="p-1 rounded-full hover:bg-black/40 text-[#9aa0a6] hover:text-white transition-colors"
                title="Remove attachment"
              >
                <X className="w-3.5 h-3.5" />
              </button>
            </div>
          </div>
        )}

        {/* Live Audio Reaction Wave Indicator when speaking */}
        {isAwake && (
          <div className="px-5 pt-2 flex items-center justify-between text-xs text-cyan-400 font-medium">
            <span className="flex items-center gap-1.5 animate-pulse">
              <span className="w-2 h-2 rounded-full bg-cyan-400" />
              Jarvis is listening for your command...
            </span>
            <div className="flex items-center gap-1">
              {[...Array(6)].map((_, i) => (
                <span
                  key={i}
                  className="w-1 bg-cyan-400 rounded-full transition-all duration-75"
                  style={{
                    height: `${Math.max(4, (audioLevel / 100) * 16 * Math.sin((i / 6) * Math.PI) + 4)}px`,
                  }}
                />
              ))}
            </div>
          </div>
        )}

        {/* Input Text Area */}
        <div className="flex items-end px-4 py-3 gap-2">
          {/* File Attachment Button */}
          <input
            type="file"
            ref={fileInputRef}
            onChange={handleFileChange}
            accept="image/*,.pdf,.txt,.csv"
            className="hidden"
          />
          <button
            type="button"
            onClick={() => fileInputRef.current?.click()}
            className="p-2 rounded-full hover:bg-[#333537] text-[#c4c7c5] hover:text-white transition-colors shrink-0 mb-0.5"
            title="Attach image or file"
          >
            <Paperclip className="w-5 h-5" />
          </button>

          {/* Text Area */}
          <textarea
            ref={textareaRef}
            rows={1}
            value={prompt}
            onChange={(e) => onChangePrompt(e.target.value)}
            onKeyDown={handleKeyDown}
            placeholder={
              isAwake
                ? "Jarvis is listening for your command..."
                : "Ask Jarvis or say 'Hey Jarvis'..."
            }
            className="flex-1 bg-transparent text-[#e3e3e3] placeholder-[#9aa0a6] text-[15px] resize-none outline-none max-h-44 py-1 leading-relaxed"
          />

          {/* Right Action Icons: Mic, Live Voice, Send */}
          <div className="flex items-center gap-1.5 shrink-0 mb-0.5">
            {/* Mic Button with animated radar pulses */}
            <div className="relative flex items-center justify-center">
              {isAwake && (
                <span className="absolute -inset-1.5 rounded-full border border-cyan-400/50 animate-ping opacity-30 pointer-events-none" />
              )}
              <button
                type="button"
                onClick={onToggleMic}
                className={`p-2 rounded-full transition-all ${
                  isAwake
                    ? 'bg-gradient-to-tr from-cyan-400 to-blue-500 text-black shadow-lg shadow-cyan-500/30'
                    : isListening
                    ? 'bg-cyan-500/20 text-[#38bdf8] hover:bg-cyan-500/30'
                    : 'hover:bg-[#333537] text-[#c4c7c5] hover:text-white'
                }`}
                title={
                  isAwake
                    ? 'Jarvis is listening now (tap to cancel)'
                    : isListening
                    ? 'Mic listening for "Hey Jarvis" (tap to speak directly)'
                    : 'Enable microphone'
                }
              >
                {isListening ? (
                  <Mic className="w-5 h-5 stroke-[2.2]" />
                ) : (
                  <MicOff className="w-5 h-5" />
                )}
              </button>
            </div>

            {/* Live Voice Orb Mode Launcher */}
            <button
              type="button"
              onClick={onOpenLiveVoice}
              className="p-2 rounded-full hover:bg-[#333537] text-[#38bdf8] hover:text-white transition-colors"
              title="Jarvis Live Voice Mode"
            >
              <Radio className="w-5 h-5 text-cyan-400 animate-pulse" />
            </button>

            {/* Send or Stop Button */}
            {isLoading ? (
              <button
                type="button"
                onClick={onStop}
                className="w-9 h-9 rounded-full bg-white text-black hover:bg-zinc-200 flex items-center justify-center transition-all shadow-md"
                title="Stop generation"
              >
                <Square className="w-3.5 h-3.5 fill-current" />
              </button>
            ) : (
              <button
                type="button"
                onClick={onSubmit}
                disabled={!canSubmit}
                className={`w-9 h-9 rounded-full flex items-center justify-center transition-all shadow-md ${
                  canSubmit
                    ? 'bg-gradient-to-r from-cyan-400 to-blue-500 text-black hover:brightness-110'
                    : 'bg-[#282a2c] text-[#5f6368] cursor-not-allowed'
                }`}
                title="Send message"
              >
                <ArrowUp className="w-4 h-4 stroke-[2.5]" />
              </button>
            )}
          </div>
        </div>
      </div>

      {/* Footer Disclaimer */}
      <div className="text-center text-[11px] text-[#9aa0a6] mt-2 select-none flex items-center justify-center gap-1.5">
        <span>Jarvis can make mistakes, so double-check it.</span>
        <span className="text-[#38bdf8]">• Hands-free Jarvis active</span>
      </div>
    </div>
  );
};
