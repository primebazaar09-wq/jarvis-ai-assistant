import React, { useState } from 'react';
import {
  X,
  Shield,
  Zap,
  Eye,
  Cpu,
  Check,
  Sparkles,
  Layers,
  ArrowRight,
  Info,
  Radio,
} from 'lucide-react';
import {
  AISystemType,
  AI_SYSTEMS,
  REAL_LIFE_VS_FICTION_INFO,
} from '../types';

interface StarkEcosystemModalProps {
  isOpen: boolean;
  onClose: () => void;
  activeSystem: AISystemType;
  onSelectSystem: (system: AISystemType) => void;
  onAskAboutSystem: (question: string) => void;
}

export const StarkEcosystemModal: React.FC<StarkEcosystemModalProps> = ({
  isOpen,
  onClose,
  activeSystem,
  onSelectSystem,
  onAskAboutSystem,
}) => {
  const [selectedTab, setSelectedTab] = useState<AISystemType>(activeSystem);

  if (!isOpen) return null;

  const currentSystem = AI_SYSTEMS[selectedTab];

  return (
    <div
      role="dialog"
      aria-modal="true"
      aria-label="Mahesh's Advanced AI Systems: JARVIS, FRIDAY, E.D.I.T.H."
      className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/75 backdrop-blur-md animate-in fade-in duration-200 select-none"
    >
      <div className="relative w-full max-w-3xl rounded-3xl bg-[#1e1f20] border border-[#3c4043] shadow-2xl overflow-hidden flex flex-col max-h-[90vh]">
        {/* Header */}
        <div className="flex items-center justify-between p-6 border-b border-[#3c4043]/50 bg-[#17181a]">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-2xl bg-gradient-to-tr from-cyan-500 via-blue-600 to-purple-600 flex items-center justify-center text-white shadow-lg shadow-cyan-500/20">
              <Layers className="w-5 h-5" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h2 className="text-lg font-semibold text-white tracking-tight">
                  Mahesh's Advanced AI Systems
                </h2>
                <span className="text-[10px] uppercase font-bold tracking-wider px-2 py-0.5 rounded-full bg-cyan-500/10 text-cyan-300 border border-cyan-500/30">
                  Stark Ecosystem
                </span>
              </div>
              <p className="text-xs text-[#9aa0a6] mt-0.5">
                JARVIS • FRIDAY • E.D.I.T.H.
              </p>
            </div>
          </div>

          <button
            onClick={onClose}
            className="p-2 rounded-full hover:bg-[#282a2c] text-[#9aa0a6] hover:text-white transition-colors"
            title="Close"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* System Tabs */}
        <div className="grid grid-cols-3 border-b border-[#3c4043]/40 bg-[#131314]">
          {(['JARVIS', 'FRIDAY', 'EDITH'] as AISystemType[]).map((sysKey) => {
            const sys = AI_SYSTEMS[sysKey];
            const isActive = selectedTab === sysKey;
            const isCurrentlyActiveSystem = activeSystem === sysKey;

            return (
              <button
                key={sysKey}
                onClick={() => setSelectedTab(sysKey)}
                className={`py-3.5 px-4 text-xs font-semibold flex items-center justify-center gap-2 transition-all border-b-2 ${
                  isActive
                    ? 'border-cyan-400 text-white bg-[#1e1f20]'
                    : 'border-transparent text-[#9aa0a6] hover:text-[#e3e3e3] hover:bg-[#1a1b1d]'
                }`}
              >
                {sysKey === 'JARVIS' && <Zap className="w-4 h-4 text-cyan-400" />}
                {sysKey === 'FRIDAY' && <Shield className="w-4 h-4 text-emerald-400" />}
                {sysKey === 'EDITH' && <Eye className="w-4 h-4 text-purple-400" />}
                <span>{sys.name}</span>
                {isCurrentlyActiveSystem && (
                  <span className="w-1.5 h-1.5 rounded-full bg-cyan-400 animate-pulse" />
                )}
              </button>
            );
          })}
        </div>

        {/* Content Body */}
        <div className="p-6 overflow-y-auto space-y-6 flex-1 text-sm">
          {/* Active System Overview Card */}
          <div className="rounded-2xl bg-[#18191c] border border-[#3c4043]/60 p-5 space-y-4 shadow-sm">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
              <div>
                <div className="flex items-center gap-2">
                  <span className="text-xl font-bold text-white tracking-tight">
                    {currentSystem.name}
                  </span>
                  <span
                    className={`text-[11px] font-mono px-2 py-0.5 rounded-full border ${currentSystem.badgeColor}`}
                  >
                    {currentSystem.fullName}
                  </span>
                </div>
                <p className="text-xs text-[#9aa0a6] mt-1 italic">
                  {currentSystem.tagline}
                </p>
              </div>

              {activeSystem === selectedTab ? (
                <div className="flex items-center gap-1.5 px-3 py-1.5 rounded-full bg-emerald-500/10 border border-emerald-500/30 text-emerald-300 text-xs font-medium w-fit">
                  <Check className="w-3.5 h-3.5" />
                  <span>Active Assistant</span>
                </div>
              ) : (
                <button
                  onClick={() => {
                    onSelectSystem(selectedTab);
                  }}
                  className="px-4 py-1.5 rounded-full bg-cyan-500 hover:bg-cyan-400 text-black text-xs font-semibold transition-all shadow-sm w-fit"
                >
                  Switch to {currentSystem.name}
                </button>
              )}
            </div>

            <p className="text-xs text-[#c4c7c5] leading-relaxed">
              {currentSystem.description}
            </p>

            {/* Core Capabilities */}
            <div className="pt-2">
              <div className="text-xs font-semibold uppercase tracking-wider text-[#9aa0a6] mb-2 flex items-center gap-1.5">
                <Cpu className="w-3.5 h-3.5 text-cyan-400" />
                Core Tactical Capabilities
              </div>
              <ul className="grid grid-cols-1 sm:grid-cols-2 gap-2 text-xs text-[#e3e3e3]">
                {currentSystem.capabilities.map((cap, i) => (
                  <li
                    key={i}
                    className="flex items-start gap-2 bg-[#202226] p-2.5 rounded-xl border border-[#3c4043]/40"
                  >
                    <span className="w-1.5 h-1.5 rounded-full bg-cyan-400 mt-1.5 shrink-0" />
                    <span>{cap}</span>
                  </li>
                ))}
              </ul>
            </div>

            {/* Voice & Wake Words */}
            <div className="flex flex-wrap items-center justify-between gap-2 pt-2 border-t border-[#3c4043]/40 text-xs">
              <div className="flex items-center gap-2 text-[#9aa0a6]">
                <Radio className="w-3.5 h-3.5 text-cyan-400" />
                <span>Wake phrases:</span>
                <span className="font-mono text-cyan-300">
                  {currentSystem.wakeWords.map((w) => `"${w}"`).join(', ')}
                </span>
              </div>
              <button
                onClick={() => {
                  onClose();
                  onAskAboutSystem(
                    `Tell me in detail about ${currentSystem.name} (${currentSystem.fullName}), its capabilities, and how Tony Stark uses it.`
                  );
                }}
                className="text-xs text-[#38bdf8] hover:underline flex items-center gap-1 font-medium"
              >
                <span>Ask about {currentSystem.name}</span>
                <ArrowRight className="w-3 h-3" />
              </button>
            </div>
          </div>

          {/* Real-Life vs Marvel Fiction Breakdown */}
          <div className="rounded-2xl bg-gradient-to-br from-[#1b1c20] to-[#141518] border border-[#3c4043]/70 p-5 space-y-3">
            <div className="flex items-center gap-2 text-white font-semibold text-xs uppercase tracking-wider">
              <Info className="w-4 h-4 text-[#38bdf8]" />
              Real Life vs. Fictional Stark Capabilities
            </div>
            <p className="text-xs text-[#9aa0a6] leading-relaxed">
              {REAL_LIFE_VS_FICTION_INFO.overview}
            </p>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-3 pt-1">
              <div className="p-3.5 rounded-xl bg-emerald-950/20 border border-emerald-500/30">
                <div className="text-xs font-bold text-emerald-400 flex items-center gap-1.5 mb-2">
                  <Check className="w-3.5 h-3.5" />
                  Buildable in Real Life Today
                </div>
                <ul className="space-y-1.5 text-xs text-[#c4c7c5]">
                  {REAL_LIFE_VS_FICTION_INFO.realLifeCapabilities.map((item, idx) => (
                    <li key={idx} className="flex items-start gap-1.5">
                      <span className="text-emerald-400 font-bold">•</span>
                      <span>{item}</span>
                    </li>
                  ))}
                </ul>
              </div>

              <div className="p-3.5 rounded-xl bg-purple-950/20 border border-purple-500/30">
                <div className="text-xs font-bold text-purple-300 flex items-center gap-1.5 mb-2">
                  <Sparkles className="w-3.5 h-3.5" />
                  Marvel Sci-Fi Fictional Frontiers
                </div>
                <ul className="space-y-1.5 text-xs text-[#c4c7c5]">
                  {REAL_LIFE_VS_FICTION_INFO.fictionalBoundaries.map((item, idx) => (
                    <li key={idx} className="flex items-start gap-1.5">
                      <span className="text-purple-400 font-bold">•</span>
                      <span>{item}</span>
                    </li>
                  ))}
                </ul>
              </div>
            </div>
          </div>
        </div>

        {/* Footer */}
        <div className="p-4 border-t border-[#3c4043]/50 bg-[#17181a] flex items-center justify-between">
          <div className="text-[11px] text-[#9aa0a6]">
            Active AI: <strong className="text-white">{activeSystem}</strong>
          </div>
          <button
            onClick={onClose}
            className="px-5 py-2 rounded-xl bg-[#282a2c] hover:bg-[#333537] text-white text-xs font-medium transition-colors"
          >
            Done
          </button>
        </div>
      </div>
    </div>
  );
};
