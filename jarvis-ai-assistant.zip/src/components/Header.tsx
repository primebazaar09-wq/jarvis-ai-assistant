import React, { useState, useRef, useEffect } from 'react';
import {
  Menu,
  ChevronDown,
  Zap,
  Radio,
  Volume2,
  VolumeX,
  Settings,
  Mic,
  Brain,
  Shield,
  Eye,
  Eraser,
  Layers,
} from 'lucide-react';
import { JarvisWordmark } from './GeminiLogo';
import { AISystemType, AI_SYSTEMS } from '../types';

interface HeaderProps {
  onToggleSidebar: () => void;
  selectedModel: 'gemini-3.5-flash' | 'gemini-3.8-flash' | 'gemini-4-argon';
  onSelectModel: (model: 'gemini-3.5-flash' | 'gemini-3.8-flash' | 'gemini-4-argon') => void;
  wakeWordActive: boolean;
  onToggleWakeWord: () => void;
  onOpenLiveVoice: () => void;
  onOpenSettings: () => void;
  isAwake: boolean;
  onSimulateWakeWord: () => void;
  autoSpeak: boolean;
  onToggleAutoSpeak: () => void;
  activeAISystem: AISystemType;
  onSelectAISystem: (system: AISystemType) => void;
  onOpenStarkEcosystem: () => void;
  hasMessages: boolean;
  onClearConversation: () => void;
}

export const Header: React.FC<HeaderProps> = ({
  onToggleSidebar,
  selectedModel,
  onSelectModel,
  wakeWordActive,
  onToggleWakeWord,
  onOpenLiveVoice,
  onOpenSettings,
  isAwake,
  onSimulateWakeWord,
  autoSpeak,
  onToggleAutoSpeak,
  activeAISystem,
  onSelectAISystem,
  onOpenStarkEcosystem,
  hasMessages,
  onClearConversation,
}) => {
  const [modelDropdownOpen, setModelDropdownOpen] = useState(false);
  const [systemDropdownOpen, setSystemDropdownOpen] = useState(false);
  const dropdownRef = useRef<HTMLDivElement>(null);
  const sysDropdownRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const handleClickOutside = (e: MouseEvent) => {
      if (dropdownRef.current && !dropdownRef.current.contains(e.target as Node)) {
        setModelDropdownOpen(false);
      }
      if (sysDropdownRef.current && !sysDropdownRef.current.contains(e.target as Node)) {
        setSystemDropdownOpen(false);
      }
    };
    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, []);

  const currentSys = AI_SYSTEMS[activeAISystem];

  const getModelLabel = () => {
    if (selectedModel === 'gemini-4-argon') return `${currentSys.name} Pro (Thinking)`;
    return `${currentSys.name} Flash`;
  };

  return (
    <header className="h-16 px-4 md:px-6 flex items-center justify-between border-b border-[#3c4043]/30 bg-[#131314]/90 backdrop-blur-md sticky top-0 z-30 select-none">
      {/* Left: Menu & System & Model Dropdown */}
      <div className="flex items-center gap-2.5 sm:gap-3">
        <button
          onClick={onToggleSidebar}
          className="p-2 rounded-full hover:bg-[#282a2c] text-[#c4c7c5] hover:text-white transition-colors md:hidden"
          title="Open menu"
          aria-label="Open menu"
        >
          <Menu className="w-5 h-5" />
        </button>

        <JarvisWordmark />

        {/* AI System Switcher Pill (JARVIS, FRIDAY, EDITH) */}
        <div className="relative" ref={sysDropdownRef}>
          <button
            onClick={() => setSystemDropdownOpen(!systemDropdownOpen)}
            className="hidden sm:flex items-center gap-1.5 px-3 py-1.5 rounded-full bg-[#1e1f20] hover:bg-[#282a2c] text-white border border-[#3c4043]/60 transition-colors text-xs font-semibold"
            title="Switch between JARVIS, FRIDAY, and E.D.I.T.H."
          >
            {activeAISystem === 'JARVIS' && <Zap className="w-3.5 h-3.5 text-cyan-400" />}
            {activeAISystem === 'FRIDAY' && <Shield className="w-3.5 h-3.5 text-emerald-400" />}
            {activeAISystem === 'EDITH' && <Eye className="w-3.5 h-3.5 text-purple-400" />}
            <span>{currentSys.name}</span>
            <ChevronDown className="w-3 h-3 text-[#9aa0a6]" />
          </button>

          {systemDropdownOpen && (
            <div className="absolute left-0 mt-2 w-72 rounded-2xl bg-[#1e1f20] border border-[#3c4043] shadow-2xl p-2 z-50 animate-in fade-in zoom-in-95 duration-150">
              <div className="flex items-center justify-between px-3 py-1.5 text-[11px] font-semibold uppercase tracking-wider text-[#9aa0a6]">
                <span>Mahesh's AI Systems</span>
                <button
                  onClick={() => {
                    setSystemDropdownOpen(false);
                    onOpenStarkEcosystem();
                  }}
                  className="text-cyan-400 hover:underline flex items-center gap-1 text-[10px]"
                >
                  <Layers className="w-3 h-3" /> Dossier
                </button>
              </div>

              {(['JARVIS', 'FRIDAY', 'EDITH'] as AISystemType[]).map((sysKey) => {
                const sys = AI_SYSTEMS[sysKey];
                const isSelected = activeAISystem === sysKey;
                return (
                  <button
                    key={sysKey}
                    onClick={() => {
                      onSelectAISystem(sysKey);
                      setSystemDropdownOpen(false);
                    }}
                    className={`w-full text-left p-2.5 rounded-xl transition-colors flex items-start gap-2.5 mt-1 ${
                      isSelected
                        ? 'bg-[#004a77]/50 text-white border border-cyan-400/30'
                        : 'hover:bg-[#282a2c] text-[#e3e3e3]'
                    }`}
                  >
                    <div className="mt-0.5">
                      {sysKey === 'JARVIS' && <Zap className="w-4 h-4 text-cyan-400" />}
                      {sysKey === 'FRIDAY' && <Shield className="w-4 h-4 text-emerald-400" />}
                      {sysKey === 'EDITH' && <Eye className="w-4 h-4 text-purple-400" />}
                    </div>
                    <div>
                      <div className="text-xs font-semibold flex items-center gap-1.5">
                        {sys.name}
                        <span className="text-[10px] text-[#9aa0a6] font-normal truncate max-w-[140px]">
                          ({sys.fullName})
                        </span>
                      </div>
                      <div className="text-[10px] text-[#9aa0a6] mt-0.5 line-clamp-1">
                        {sys.tagline}
                      </div>
                    </div>
                  </button>
                );
              })}
            </div>
          )}
        </div>

        {/* Model Picker */}
        <div className="relative" ref={dropdownRef}>
          <button
            onClick={() => setModelDropdownOpen(!modelDropdownOpen)}
            className="flex items-center gap-1.5 px-3 py-1.5 rounded-full hover:bg-[#282a2c] text-[#c4c7c5] hover:text-white transition-colors text-sm font-medium border border-[#3c4043]/40"
          >
            <span className="text-xs md:text-sm font-medium truncate max-w-[130px] sm:max-w-none">
              {getModelLabel()}
            </span>
            <ChevronDown className="w-3.5 h-3.5 text-[#9aa0a6]" />
          </button>

          {modelDropdownOpen && (
            <div className="absolute left-0 mt-2 w-72 rounded-2xl bg-[#1e1f20] border border-[#3c4043] shadow-2xl p-2 z-50 animate-in fade-in zoom-in-95 duration-150">
              <div className="px-3 py-2 text-[11px] font-semibold uppercase tracking-wider text-[#9aa0a6]">
                Select Intelligence Model
              </div>

              {/* Flash */}
              <button
                onClick={() => {
                  onSelectModel('gemini-3.5-flash');
                  setModelDropdownOpen(false);
                }}
                className={`w-full text-left p-3 rounded-xl transition-colors flex items-start gap-3 ${
                  selectedModel === 'gemini-3.5-flash' || selectedModel === 'gemini-3.8-flash'
                    ? 'bg-[#004a77]/50 text-white border border-[#8ab4f8]/30'
                    : 'hover:bg-[#282a2c] text-[#e3e3e3]'
                }`}
              >
                <Zap className="w-4 h-4 text-[#38bdf8] mt-0.5 shrink-0" />
                <div>
                  <div className="text-xs font-semibold flex items-center gap-1.5">
                    {currentSys.name} Flash
                    <span className="text-[10px] uppercase font-bold text-cyan-400 bg-cyan-500/10 px-1.5 py-0.2 rounded">
                      Fast
                    </span>
                  </div>
                  <div className="text-[11px] text-[#9aa0a6] mt-0.5">
                    Instant sub-second voice responses and conversational speed.
                  </div>
                </div>
              </button>

              {/* Pro Thinking */}
              <button
                onClick={() => {
                  onSelectModel('gemini-4-argon');
                  setModelDropdownOpen(false);
                }}
                className={`w-full text-left p-3 rounded-xl transition-colors flex items-start gap-3 mt-1 ${
                  selectedModel === 'gemini-4-argon'
                    ? 'bg-[#004a77]/50 text-white border border-[#8ab4f8]/30'
                    : 'hover:bg-[#282a2c] text-[#e3e3e3]'
                }`}
              >
                <Brain className="w-4 h-4 text-purple-400 mt-0.5 shrink-0" />
                <div>
                  <div className="text-xs font-semibold flex items-center gap-1.5">
                    {currentSys.name} Pro
                    <span className="text-[10px] uppercase font-bold text-purple-400 bg-purple-500/10 px-1.5 py-0.2 rounded">
                      Thinking
                    </span>
                  </div>
                  <div className="text-[11px] text-[#9aa0a6] mt-0.5">
                    Deep multi-step reasoning, complex coding, and analysis.
                  </div>
                </div>
              </button>
            </div>
          )}
        </div>
      </div>

      {/* Right: Clear Conversation, Wake Word status, Auto-speak, Live Voice button */}
      <div className="flex items-center gap-2 md:gap-3">
        {/* Quick Clear Conversation Button in Header when chat has messages */}
        {hasMessages && (
          <button
            onClick={onClearConversation}
            className="flex items-center gap-1.5 px-3 py-1.5 rounded-full text-xs font-medium bg-[#1e1f20] hover:bg-red-500/10 text-[#c4c7c5] hover:text-red-300 border border-[#3c4043]/50 hover:border-red-500/40 transition-colors"
            title="Clear Conversation"
          >
            <Eraser className="w-3.5 h-3.5" />
            <span className="hidden xl:inline">Clear</span>
          </button>
        )}

        {/* Wake Word Status Pill */}
        <div
          className={`flex items-center gap-2 px-3 py-1.5 rounded-full text-xs transition-all border ${
            isAwake
              ? 'bg-cyan-600/30 text-white border-cyan-400 ring-2 ring-cyan-500/30 animate-pulse'
              : wakeWordActive
              ? 'bg-[#1e1f20] text-[#c4c7c5] border-[#3c4043]/60'
              : 'bg-[#1e1f20]/50 text-zinc-500 border-zinc-800'
          }`}
        >
          <span
            className={`w-2 h-2 rounded-full ${
              isAwake
                ? 'bg-cyan-400 animate-ping'
                : wakeWordActive
                ? 'bg-emerald-400 animate-pulse'
                : 'bg-zinc-600'
            }`}
          />
          <span className="hidden sm:inline font-medium">
            {isAwake ? `${currentSys.name} Listening...` : wakeWordActive ? `"Hey ${currentSys.name}" Ready` : 'Wake Word Paused'}
          </span>
          <button
            onClick={onToggleWakeWord}
            className="text-[11px] text-[#38bdf8] hover:underline ml-1 font-semibold"
            title="Toggle wake word listener"
          >
            {wakeWordActive ? 'Mute' : 'Enable'}
          </button>
        </div>

        {/* Simulate Wake Word Test Button for quick test / headless verification */}
        <button
          onClick={onSimulateWakeWord}
          className="hidden lg:flex items-center gap-1.5 px-3 py-1.5 rounded-full text-xs font-medium bg-[#282a2c] hover:bg-[#333537] text-[#38bdf8] border border-cyan-500/30 hover:border-cyan-400/50 transition-colors shadow-xs"
          title={`Simulate saying "Hey ${currentSys.name}"`}
        >
          <Mic className="w-3.5 h-3.5 text-[#38bdf8] animate-pulse" />
          <span>Test "Hey {currentSys.name}"</span>
        </button>

        {/* Auto-Speak Responses Toggle */}
        <button
          onClick={onToggleAutoSpeak}
          className={`p-2 rounded-full transition-colors ${
            autoSpeak
              ? 'bg-cyan-500/20 text-[#38bdf8] border border-cyan-500/30'
              : 'bg-[#282a2c] text-[#9aa0a6] hover:text-white'
          }`}
          title={autoSpeak ? `${currentSys.name} Voice Output: ON` : `${currentSys.name} Voice Output: OFF`}
        >
          {autoSpeak ? <Volume2 className="w-4 h-4" /> : <VolumeX className="w-4 h-4" />}
        </button>

        {/* Live Voice Orb Button */}
        <button
          onClick={onOpenLiveVoice}
          className="flex items-center gap-2 px-3.5 py-1.5 rounded-full bg-gradient-to-r from-cyan-500 via-blue-600 to-indigo-600 hover:from-cyan-400 hover:to-indigo-500 text-white text-xs font-medium shadow-md shadow-cyan-500/20 transition-all hover:scale-105 active:scale-95"
          title={`Open ${currentSys.name} Live Voice Mode`}
        >
          <Radio className="w-3.5 h-3.5 animate-pulse" />
          <span className="hidden sm:inline font-semibold">Live {currentSys.name}</span>
        </button>

        {/* Settings Button */}
        <button
          onClick={onOpenSettings}
          className="p-2 rounded-full hover:bg-[#282a2c] text-[#c4c7c5] hover:text-white transition-colors"
          title="Voice and Assistant Settings"
        >
          <Settings className="w-4 h-4" />
        </button>
      </div>
    </header>
  );
};
