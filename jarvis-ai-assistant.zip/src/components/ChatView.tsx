import React, { useState } from 'react';
import {
  Sparkles,
  Volume2,
  VolumeX,
  Copy,
  Check,
  ThumbsUp,
  ThumbsDown,
  RotateCcw,
  ChevronDown,
  ChevronRight,
  Brain,
  Mic,
  Lightbulb,
  Code2,
  Compass,
  Zap,
  Shield,
  Eye,
  Layers,
} from 'lucide-react';
import { ChatMessage, AISystemType, AI_SYSTEMS } from '../types';
import { MarkdownRenderer } from '../utils/markdownParser';
import { JarvisSparkleIcon } from './GeminiLogo';

interface ChatViewProps {
  messages: ChatMessage[];
  isLoading: boolean;
  onSelectPrompt: (prompt: string) => void;
  onSpeakMessage: (id: string, text: string) => void;
  onStopSpeaking: () => void;
  activeSpeakingMessageId: string | null;
  onRegenerate: () => void;
  onSimulateWakeWord: () => void;
  activeAISystem?: AISystemType;
  onOpenStarkEcosystem?: () => void;
}

export const ChatView: React.FC<ChatViewProps> = ({
  messages,
  isLoading,
  onSelectPrompt,
  onSpeakMessage,
  onStopSpeaking,
  activeSpeakingMessageId,
  onRegenerate,
  onSimulateWakeWord,
  activeAISystem = 'JARVIS',
  onOpenStarkEcosystem,
}) => {
  const [copiedId, setCopiedId] = useState<string | null>(null);
  const [expandedThinkingIds, setExpandedThinkingIds] = useState<Record<string, boolean>>({});
  const [feedback, setFeedback] = useState<Record<string, 'up' | 'down'>>({});

  const currentSys = AI_SYSTEMS[activeAISystem];

  const handleCopy = async (id: string, text: string) => {
    try {
      await navigator.clipboard.writeText(text);
      setCopiedId(id);
      setTimeout(() => setCopiedId(null), 2000);
    } catch (e) {
      console.error(e);
    }
  };

  const toggleThinking = (id: string) => {
    setExpandedThinkingIds((prev) => ({
      ...prev,
      [id]: !prev[id],
    }));
  };

  if (messages.length === 0) {
    return (
      <div className="flex-1 overflow-y-auto px-4 py-8 flex flex-col justify-center items-center max-w-4xl mx-auto w-full select-none">
        {/* Colorful Greeting */}
        <div className="text-left w-full mb-8 pl-2">
          <div className="flex items-center gap-2 mb-2">
            <JarvisSparkleIcon className="w-8 h-8" />
            <span className="text-xs font-bold uppercase tracking-wider text-[#38bdf8] flex items-center gap-1.5">
              {activeAISystem === 'JARVIS' && <Zap className="w-3.5 h-3.5 text-cyan-400" />}
              {activeAISystem === 'FRIDAY' && <Shield className="w-3.5 h-3.5 text-emerald-400" />}
              {activeAISystem === 'EDITH' && <Eye className="w-3.5 h-3.5 text-purple-400" />}
              {currentSys.name} AI ASSISTANT • STARK ECOSYSTEM
            </span>
          </div>
          <h1 className="text-4xl md:text-5xl font-['Google_Sans',sans-serif] font-medium tracking-tight bg-gradient-to-r from-[#38bdf8] via-[#818cf8] to-[#c084fc] bg-clip-text text-transparent pb-1">
            Hello, friend
          </h1>
          <p className="text-xl md:text-2xl text-[#9aa0a6] font-['Google_Sans_Text',sans-serif] font-normal mt-1">
            How can {currentSys.name} assist you today?
          </p>
          <div className="mt-4 flex flex-wrap items-center gap-2 text-xs">
            <div className="flex items-center gap-2 text-[#c4c7c5] bg-[#1e1f20] px-3.5 py-2 rounded-full border border-[#3c4043]/50 shadow-xs">
              <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse" />
              <span>
                Hands-free active: Say <strong className="text-white">"Hey {currentSys.name}"</strong> anytime.
              </span>
              <button
                onClick={onSimulateWakeWord}
                className="text-[#38bdf8] hover:underline ml-1 font-semibold"
              >
                Test Wake Word
              </button>
            </div>

            {onOpenStarkEcosystem && (
              <button
                onClick={onOpenStarkEcosystem}
                className="flex items-center gap-1.5 px-3 py-2 rounded-full bg-[#1e1f20] hover:bg-[#282a2c] text-[#38bdf8] border border-cyan-500/30 transition-colors font-medium shadow-xs"
              >
                <Layers className="w-3.5 h-3.5" />
                <span>View Stark AI Ecosystem (JARVIS, FRIDAY, E.D.I.T.H.)</span>
              </button>
            )}
          </div>
        </div>

        {/* Suggestion Prompt Cards */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-3.5 w-full">
          {/* Stark Ecosystem Prompt */}
          <button
            onClick={() =>
              onSelectPrompt(
                'Explain Mahesh\'s three advanced AI systems: JARVIS, FRIDAY, and E.D.I.T.H., their capabilities, and how they compare to real-world AI today.'
              )
            }
            className="p-4 rounded-2xl bg-gradient-to-br from-[#1a2333]/70 to-[#1e1f20] hover:bg-[#282a2c] border border-cyan-500/30 hover:border-cyan-400/50 text-left transition-all group flex flex-col justify-between h-36"
          >
            <div className="text-sm text-[#e3e3e3] font-medium group-hover:text-white leading-snug">
              Compare Mahesh's 3 AI systems: JARVIS, FRIDAY, and E.D.I.T.H. & real-world parallels
            </div>
            <div className="flex items-center justify-between text-xs text-[#9aa0a6]">
              <span className="flex items-center gap-1.5 text-cyan-300 font-semibold">
                <Layers className="w-3.5 h-3.5" />
                Stark AI Ecosystem
              </span>
              <div className="w-7 h-7 rounded-full bg-[#282a2c] group-hover:bg-[#333537] flex items-center justify-center text-[#c4c7c5]">
                <Sparkles className="w-3.5 h-3.5 text-cyan-400" />
              </div>
            </div>
          </button>

          {/* Voice Prompt */}
          <button
            onClick={() =>
              onSelectPrompt(`Hey ${currentSys.name}, what are 3 mind-bending facts about the James Webb Space Telescope?`)
            }
            className="p-4 rounded-2xl bg-[#1e1f20] hover:bg-[#282a2c] border border-[#3c4043]/50 hover:border-[#38bdf8]/40 text-left transition-all group flex flex-col justify-between h-36"
          >
            <div className="text-sm text-[#e3e3e3] font-medium group-hover:text-white leading-snug">
              "Hey {currentSys.name}, what are 3 mind-bending facts about the James Webb Space Telescope?"
            </div>
            <div className="flex items-center justify-between text-xs text-[#9aa0a6]">
              <span className="flex items-center gap-1.5 text-[#38bdf8]">
                <Mic className="w-3.5 h-3.5 animate-pulse" />
                Hands-free voice prompt
              </span>
              <div className="w-7 h-7 rounded-full bg-[#282a2c] group-hover:bg-[#333537] flex items-center justify-center text-[#c4c7c5]">
                <Sparkles className="w-3.5 h-3.5 text-[#38bdf8]" />
              </div>
            </div>
          </button>

          {/* Code Prompt */}
          <button
            onClick={() =>
              onSelectPrompt(
                "Write a TypeScript WebSocket client implementation with exponential backoff and message queueing"
              )
            }
            className="p-4 rounded-2xl bg-[#1e1f20] hover:bg-[#282a2c] border border-[#3c4043]/50 hover:border-[#38bdf8]/40 text-left transition-all group flex flex-col justify-between h-36"
          >
            <div className="text-sm text-[#e3e3e3] font-medium group-hover:text-white leading-snug">
              Write a robust TypeScript WebSocket client with auto-reconnect and queueing
            </div>
            <div className="flex items-center justify-between text-xs text-[#9aa0a6]">
              <span className="flex items-center gap-1.5 text-purple-400">
                <Code2 className="w-3.5 h-3.5" />
                Code & Architecture
              </span>
              <div className="w-7 h-7 rounded-full bg-[#282a2c] group-hover:bg-[#333537] flex items-center justify-center text-[#c4c7c5]">
                <Code2 className="w-3.5 h-3.5 text-purple-400" />
              </div>
            </div>
          </button>

          {/* Tactical / Technical Concept */}
          <button
            onClick={() =>
              onSelectPrompt("Compare quantum computing qubits vs classical bits in simple, visual terms")
            }
            className="p-4 rounded-2xl bg-[#1e1f20] hover:bg-[#282a2c] border border-[#3c4043]/50 hover:border-[#38bdf8]/40 text-left transition-all group flex flex-col justify-between h-36"
          >
            <div className="text-sm text-[#e3e3e3] font-medium group-hover:text-white leading-snug">
              Compare quantum computing qubits vs classical bits in simple terms
            </div>
            <div className="flex items-center justify-between text-xs text-[#9aa0a6]">
              <span className="flex items-center gap-1.5 text-amber-400">
                <Lightbulb className="w-3.5 h-3.5" />
                Explain a concept
              </span>
              <div className="w-7 h-7 rounded-full bg-[#282a2c] group-hover:bg-[#333537] flex items-center justify-center text-[#c4c7c5]">
                <Lightbulb className="w-3.5 h-3.5 text-amber-400" />
              </div>
            </div>
          </button>
        </div>
      </div>
    );
  }

  return (
    <div className="flex-1 overflow-y-auto px-4 md:px-8 py-6 space-y-6 max-w-4xl mx-auto w-full">
      {messages.map((msg, index) => {
        const isUser = msg.role === 'user';
        const isSpeaking = activeSpeakingMessageId === msg.id;

        if (isUser) {
          return (
            <div key={msg.id} className="flex justify-end items-start gap-3">
              <div className="max-w-[85%] md:max-w-[75%] rounded-3xl bg-[#282a2c] px-5 py-3.5 text-[#e3e3e3] shadow-xs">
                {/* Image attachment preview if present */}
                {msg.attachment && (
                  <div className="mb-2 rounded-xl overflow-hidden max-w-xs border border-[#3c4043]">
                    {msg.attachment.mimeType.startsWith('image/') ? (
                      <img
                        src={msg.attachment.data}
                        alt={msg.attachment.name}
                        className="w-full h-auto object-cover max-h-60"
                      />
                    ) : (
                      <div className="p-3 text-xs text-[#38bdf8] bg-[#1e1f20]">
                        📎 {msg.attachment.name}
                      </div>
                    )}
                  </div>
                )}
                <div className="text-[15px] whitespace-pre-wrap leading-relaxed select-text">
                  {msg.text}
                </div>
              </div>

              {/* User Avatar */}
              <div className="w-8 h-8 rounded-full bg-gradient-to-tr from-cyan-500 to-indigo-500 text-white font-medium text-xs flex items-center justify-center shrink-0 mt-1 shadow-sm">
                P
              </div>
            </div>
          );
        }

        // Assistant Model Response
        const sysLabel = msg.aiSystem || activeAISystem;
        return (
          <div key={msg.id} className="flex items-start gap-4">
            {/* Assistant Sparkle Avatar */}
            <div className="w-8 h-8 rounded-full bg-[#1e1f20] border border-cyan-500/30 flex items-center justify-center shrink-0 mt-1 shadow-xs">
              <JarvisSparkleIcon className="w-5 h-5" animate={msg.isStreaming} />
            </div>

            {/* Model Content Area */}
            <div className="flex-1 min-w-0 space-y-3">
              <div className="flex items-center gap-2">
                <span className="font-['Google_Sans',sans-serif] font-medium text-sm text-[#e3e3e3] flex items-center gap-1.5">
                  {sysLabel}
                  <span className="w-1.5 h-1.5 rounded-full bg-cyan-400" />
                </span>
                {msg.isStreaming && (
                  <span className="text-[11px] text-[#38bdf8] animate-pulse flex items-center gap-1">
                    <span className="w-1.5 h-1.5 rounded-full bg-cyan-400 animate-ping" />
                    Generating & Transmitting...
                  </span>
                )}
              </div>

              {/* Thinking / Reasoning Accordion if model thought */}
              {msg.thinking && (
                <div className="rounded-xl border border-[#3c4043]/50 bg-[#1e1f20]/60 overflow-hidden text-xs">
                  <button
                    onClick={() => toggleThinking(msg.id)}
                    className="w-full px-3 py-2 flex items-center justify-between text-[#38bdf8] hover:bg-[#282a2c]/60 transition-colors"
                  >
                    <span className="flex items-center gap-1.5 font-medium">
                      <Brain className="w-3.5 h-3.5 text-purple-400" />
                      Thought process {msg.thoughtDurationMs ? `(${Math.round(msg.thoughtDurationMs / 1000)}s)` : ''}
                    </span>
                    {expandedThinkingIds[msg.id] ? (
                      <ChevronDown className="w-3.5 h-3.5" />
                    ) : (
                      <ChevronRight className="w-3.5 h-3.5" />
                    )}
                  </button>
                  {expandedThinkingIds[msg.id] && (
                    <div className="p-3 border-t border-[#3c4043]/40 text-[#c4c7c5] whitespace-pre-wrap font-mono text-[12px] bg-[#131314]/50 leading-relaxed">
                      {msg.thinking}
                    </div>
                  )}
                </div>
              )}

              {/* Message Body */}
              <div className="select-text">
                <MarkdownRenderer content={msg.text} />
              </div>

              {/* Error notification if any */}
              {msg.error && (
                <div className="p-3 rounded-xl bg-red-950/40 border border-red-500/40 text-red-200 text-xs">
                  {msg.error}
                </div>
              )}

              {/* Action Toolbar */}
              {!msg.isStreaming && msg.text && (
                <div className="flex items-center gap-1 pt-1 text-[#9aa0a6]">
                  {/* Read Aloud / Stop Speaking Button */}
                  <button
                    onClick={() =>
                      isSpeaking ? onStopSpeaking() : onSpeakMessage(msg.id, msg.text)
                    }
                    className={`flex items-center gap-1.5 px-2.5 py-1.5 rounded-full text-xs transition-colors ${
                      isSpeaking
                        ? 'bg-cyan-500/20 text-[#38bdf8] font-medium'
                        : 'hover:bg-[#282a2c] hover:text-[#e3e3e3]'
                    }`}
                    title={isSpeaking ? 'Stop speaking' : `Read response aloud with ${sysLabel} voice`}
                  >
                    {isSpeaking ? (
                      <>
                        <VolumeX className="w-4 h-4 text-cyan-400" />
                        <span className="flex items-center gap-0.5">
                          <span className="w-1 h-3 bg-cyan-400 animate-bounce" />
                          <span className="w-1 h-2 bg-cyan-400 animate-bounce delay-75" />
                          <span className="w-1 h-4 bg-cyan-400 animate-bounce delay-150" />
                        </span>
                      </>
                    ) : (
                      <>
                        <Volume2 className="w-4 h-4" />
                        <span className="text-[11px]">Listen</span>
                      </>
                    )}
                  </button>

                  {/* Copy Button */}
                  <button
                    onClick={() => handleCopy(msg.id, msg.text)}
                    className="p-1.5 rounded-full hover:bg-[#282a2c] hover:text-[#e3e3e3] transition-colors"
                    title="Copy to clipboard"
                  >
                    {copiedId === msg.id ? (
                      <Check className="w-4 h-4 text-emerald-400" />
                    ) : (
                      <Copy className="w-4 h-4" />
                    )}
                  </button>

                  {/* Thumbs Up / Down */}
                  <button
                    onClick={() =>
                      setFeedback((prev) => ({
                        ...prev,
                        [msg.id]: prev[msg.id] === 'up' ? undefined! : 'up',
                      }))
                    }
                    className={`p-1.5 rounded-full hover:bg-[#282a2c] transition-colors ${
                      feedback[msg.id] === 'up' ? 'text-emerald-400' : 'hover:text-[#e3e3e3]'
                    }`}
                    title="Good response"
                  >
                    <ThumbsUp className="w-4 h-4" />
                  </button>

                  <button
                    onClick={() =>
                      setFeedback((prev) => ({
                        ...prev,
                        [msg.id]: prev[msg.id] === 'down' ? undefined! : 'down',
                      }))
                    }
                    className={`p-1.5 rounded-full hover:bg-[#282a2c] transition-colors ${
                      feedback[msg.id] === 'down' ? 'text-red-400' : 'hover:text-[#e3e3e3]'
                    }`}
                    title="Bad response"
                  >
                    <ThumbsDown className="w-4 h-4" />
                  </button>

                  {/* Regenerate (on latest response) */}
                  {index === messages.length - 1 && (
                    <button
                      onClick={onRegenerate}
                      className="p-1.5 rounded-full hover:bg-[#282a2c] hover:text-[#e3e3e3] transition-colors"
                      title="Regenerate response"
                    >
                      <RotateCcw className="w-4 h-4" />
                    </button>
                  )}
                </div>
              )}
            </div>
          </div>
        );
      })}
    </div>
  );
};
