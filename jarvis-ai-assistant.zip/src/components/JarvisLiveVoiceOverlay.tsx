import React, { useState, useEffect } from 'react';
import {
  X,
  Mic,
  MicOff,
  Volume2,
  VolumeX,
  Radio,
  Play,
  RotateCcw,
  Sparkles,
  Zap,
} from 'lucide-react';
import { JarvisSparkleIcon } from './GeminiLogo';

interface JarvisLiveVoiceOverlayProps {
  isOpen: boolean;
  onClose: () => void;
  isListening: boolean;
  isAwake: boolean;
  transcript: string;
  interimText: string;
  audioLevel: number; // 0 - 100
  audioSpectrum?: number[];
  isSpeaking: boolean;
  lastResponseText: string;
  onSimulateCommand: (cmd: string) => void;
  onToggleMic: () => void;
  voiceName: string;
  onChangeVoice: (voice: any) => void;
  onInterruptSpeech: () => void;
}

export const JarvisLiveVoiceOverlay: React.FC<JarvisLiveVoiceOverlayProps> = ({
  isOpen,
  onClose,
  isListening,
  isAwake,
  transcript,
  interimText,
  audioLevel,
  audioSpectrum = [10, 20, 35, 45, 30, 20, 15, 10],
  isSpeaking,
  lastResponseText,
  onSimulateCommand,
  onToggleMic,
  voiceName,
  onChangeVoice,
  onInterruptSpeech,
}) => {
  const [pulseScale, setPulseScale] = useState(1);

  // Dynamic orb scaling reacting to real speech cadence or Jarvis output
  useEffect(() => {
    if (!isOpen) return;

    if (isSpeaking) {
      const interval = setInterval(() => {
        setPulseScale(1 + Math.sin(Date.now() / 140) * 0.18 + Math.random() * 0.1);
      }, 70);
      return () => clearInterval(interval);
    } else if (audioLevel > 4) {
      setPulseScale(1 + (audioLevel / 100) * 0.5);
    } else if (isAwake) {
      setPulseScale(1.15 + Math.sin(Date.now() / 260) * 0.08);
    } else {
      setPulseScale(1);
    }
  }, [audioLevel, isSpeaking, isAwake, isOpen]);

  if (!isOpen) return null;

  const currentDisplaySpeech = interimText || transcript;

  return (
    <div
      role="dialog"
      aria-modal="true"
      aria-label="Jarvis Live Voice Assistant"
      className="fixed inset-0 z-50 flex flex-col justify-between bg-[#0a0a0f]/95 backdrop-blur-3xl text-white select-none animate-in fade-in duration-300"
    >
      {/* Background Animated Ambient Lights */}
      <div className="absolute inset-0 pointer-events-none overflow-hidden">
        <div className="absolute -top-32 left-1/2 -translate-x-1/2 w-[700px] h-[400px] bg-gradient-to-b from-cyan-500/10 via-blue-600/10 to-transparent rounded-full blur-3xl animate-pulse [animation-duration:8s]" />
        <div className="absolute -bottom-32 left-1/2 -translate-x-1/2 w-[600px] h-[300px] bg-gradient-to-t from-purple-600/10 to-transparent rounded-full blur-3xl" />
      </div>

      {/* Top Bar */}
      <div className="relative z-10 flex items-center justify-between p-6">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-2xl bg-gradient-to-tr from-cyan-500 via-blue-600 to-indigo-600 p-0.5 shadow-lg shadow-cyan-500/20">
            <div className="w-full h-full bg-[#101216] rounded-[14px] flex items-center justify-center">
              <JarvisSparkleIcon className="w-5 h-5" animate={isSpeaking || isAwake} />
            </div>
          </div>
          <div>
            <div className="font-['Google_Sans',sans-serif] font-semibold text-base tracking-tight flex items-center gap-2">
              Jarvis Live Voice
              <span className="text-[10px] font-bold uppercase tracking-wider px-2 py-0.5 rounded-full bg-cyan-500/20 text-[#38bdf8] border border-cyan-500/40">
                Live HUD
              </span>
            </div>
            <div className="text-xs text-[#9aa0a6] flex items-center gap-1.5 mt-0.5">
              <span
                className={`w-2 h-2 rounded-full ${
                  isSpeaking
                    ? 'bg-purple-400 animate-pulse'
                    : isAwake
                    ? 'bg-cyan-400 animate-ping'
                    : isListening
                    ? 'bg-emerald-400 animate-pulse'
                    : 'bg-zinc-600'
                }`}
              />
              {isSpeaking
                ? `Jarvis Speaking (${voiceName})`
                : isAwake
                ? 'Listening to your command...'
                : isListening
                ? 'Standing by: Say "Hey Jarvis"'
                : 'Microphone Paused'}
            </div>
          </div>
        </div>

        {/* Voice Selector & Close Button */}
        <div className="flex items-center gap-3">
          <select
            value={voiceName}
            onChange={(e) => onChangeVoice(e.target.value)}
            className="bg-[#1e1f20] text-xs text-[#c4c7c5] px-3.5 py-2 rounded-xl border border-[#3c4043] focus:outline-none focus:border-cyan-500/50 transition-colors"
            title="Select Jarvis Voice"
          >
            <option value="Zephyr">Voice: Zephyr (Warm & Dynamic)</option>
            <option value="Kore">Voice: Kore (Calm & Clear)</option>
            <option value="Fenrir">Voice: Fenrir (Deep & Resonant)</option>
            <option value="Puck">Voice: Puck (Engaging & Crisp)</option>
            <option value="Charon">Voice: Charon (Direct & Focused)</option>
          </select>

          <button
            onClick={onClose}
            className="p-2.5 rounded-full bg-[#1e1f20] hover:bg-[#282a2c] text-[#c4c7c5] hover:text-white transition-colors border border-[#3c4043]/50"
            title="Exit Live Voice Mode"
          >
            <X className="w-5 h-5" />
          </button>
        </div>
      </div>

      {/* Center: Glowing Holographic Jarvis Arc Reactor Orb & Live Speech HUD */}
      <div className="relative z-10 flex-1 flex flex-col items-center justify-center px-6 text-center max-w-2xl mx-auto w-full">
        {/* Pulsing Visual Orb */}
        <div className="relative flex items-center justify-center my-6">
          {/* Ambient Glow halo */}
          <div
            className="absolute rounded-full transition-transform duration-100 ease-out filter blur-3xl pointer-events-none opacity-70"
            style={{
              width: `${260 * pulseScale}px`,
              height: `${260 * pulseScale}px`,
              background: isSpeaking
                ? 'radial-gradient(circle, #818cf8 0%, #38bdf8 50%, transparent 80%)'
                : isAwake
                ? 'radial-gradient(circle, #00f2fe 0%, #4facfe 60%, transparent 85%)'
                : 'radial-gradient(circle, #38bdf8 0%, #6366f1 45%, transparent 80%)',
            }}
          />

          {/* Outer Holographic Radar Ring */}
          <div
            className="absolute rounded-full border border-cyan-400/30 animate-[spin_12s_linear_infinite]"
            style={{
              width: `${220 * pulseScale}px`,
              height: `${220 * pulseScale}px`,
            }}
          >
            <div className="absolute top-0 left-1/2 -translate-x-1/2 w-2 h-2 rounded-full bg-cyan-400 shadow-md shadow-cyan-400" />
            <div className="absolute bottom-0 left-1/2 -translate-x-1/2 w-1.5 h-1.5 rounded-full bg-blue-400" />
          </div>

          {/* Middle Rotating Dash Ring */}
          <div
            className="absolute rounded-full border border-dashed border-indigo-400/40 animate-[spin_20s_linear_infinite_reverse]"
            style={{
              width: `${195 * pulseScale}px`,
              height: `${195 * pulseScale}px`,
            }}
          />

          {/* Core Fluid Jarvis Orb */}
          <div
            className="relative rounded-full transition-transform duration-75 ease-out shadow-2xl flex items-center justify-center overflow-hidden"
            style={{
              width: `${170 * pulseScale}px`,
              height: `${170 * pulseScale}px`,
              background: isSpeaking
                ? 'linear-gradient(135deg, #6366f1 0%, #38bdf8 50%, #06b6d4 100%)'
                : isAwake
                ? 'linear-gradient(135deg, #0ea5e9 0%, #06b6d4 50%, #38bdf8 100%)'
                : 'linear-gradient(135deg, #1e3a8a 0%, #3b82f6 50%, #06b6d4 100%)',
            }}
          >
            {/* Inner dynamic ripples */}
            <div className="absolute inset-2 rounded-full border border-white/20 animate-spin [animation-duration:8s]" />
            <div className="absolute inset-6 rounded-full border border-white/40 animate-ping opacity-25" />
            <JarvisSparkleIcon className="w-12 h-12 text-white drop-shadow-md z-10" />
          </div>
        </div>

        {/* Live Audio Spectrum Equalizer */}
        <div className="flex items-center gap-1.5 h-10 my-3">
          {audioSpectrum.map((band, i) => {
            const height = isSpeaking
              ? Math.max(6, Math.sin(i * 0.7 + Date.now() / 90) * 26 + 10)
              : Math.max(6, Math.round((band / 100) * 32));
            return (
              <div
                key={i}
                className="w-1.5 rounded-full bg-gradient-to-t from-cyan-400 via-blue-500 to-indigo-400 transition-all duration-75"
                style={{ height: `${height}px` }}
              />
            );
          })}
        </div>

        {/* Live Captioning & Spoken Text */}
        <div className="min-h-24 flex flex-col items-center justify-center w-full px-4">
          {currentDisplaySpeech ? (
            <div className="text-xl md:text-2xl font-medium text-white tracking-tight leading-snug animate-in fade-in duration-150">
              "{currentDisplaySpeech}"
            </div>
          ) : isSpeaking ? (
            <div className="text-lg text-[#c4c7c5] line-clamp-3 italic leading-relaxed">
              "{lastResponseText.slice(0, 160)}..."
            </div>
          ) : isAwake ? (
            <div className="text-xl text-[#38bdf8] font-medium animate-pulse flex items-center gap-2">
              <Zap className="w-5 h-5 text-cyan-400" />
              Jarvis is awake. Speak your question now...
            </div>
          ) : (
            <div className="space-y-1">
              <div className="text-xl text-[#c4c7c5] font-light">
                Say <strong className="font-semibold text-white">"Hey Jarvis"</strong> to begin hands-free
              </div>
              <div className="text-xs text-[#9aa0a6]">
                Or tap the mic button below to talk directly
              </div>
            </div>
          )}
        </div>

        {/* Quick Simulation Chips */}
        <div className="flex flex-wrap items-center justify-center gap-2 mt-6">
          <button
            onClick={() => onSimulateCommand('Hey Jarvis, what is artificial general intelligence?')}
            className="text-xs px-3.5 py-1.5 rounded-full bg-[#181a20] hover:bg-[#22252e] text-[#38bdf8] border border-[#2d3139] hover:border-cyan-500/40 transition-colors flex items-center gap-1.5"
          >
            <Play className="w-3 h-3 fill-current" />
            "Hey Jarvis, what is AGI?"
          </button>
          <button
            onClick={() => onSimulateCommand('Hey Jarvis, tell me an inspiring quote by Albert Einstein')}
            className="text-xs px-3.5 py-1.5 rounded-full bg-[#181a20] hover:bg-[#22252e] text-[#38bdf8] border border-[#2d3139] hover:border-cyan-500/40 transition-colors flex items-center gap-1.5"
          >
            <Play className="w-3 h-3 fill-current" />
            "Hey Jarvis, Einstein quote"
          </button>
          <button
            onClick={() => onSimulateCommand('Hey Jarvis, how fast does light travel?')}
            className="text-xs px-3.5 py-1.5 rounded-full bg-[#181a20] hover:bg-[#22252e] text-[#38bdf8] border border-[#2d3139] hover:border-cyan-500/40 transition-colors flex items-center gap-1.5"
          >
            <Play className="w-3 h-3 fill-current" />
            "Hey Jarvis, speed of light"
          </button>
        </div>
      </div>

      {/* Bottom Controls Bar */}
      <div className="relative z-10 p-6 flex items-center justify-center gap-4 bg-gradient-to-t from-black/80 to-transparent">
        {/* Interrupt Speech Button if Jarvis is talking */}
        {isSpeaking && (
          <button
            onClick={onInterruptSpeech}
            className="px-4 py-2.5 rounded-full bg-red-600/20 hover:bg-red-600/30 text-red-300 border border-red-500/40 text-xs font-semibold flex items-center gap-2 transition-all shadow-md animate-pulse"
          >
            <VolumeX className="w-4 h-4" />
            Interrupt Speech
          </button>
        )}

        {/* Mic Toggle Button */}
        <div className="relative">
          {isListening && (
            <span className="absolute -inset-2 rounded-full border border-cyan-400/40 animate-ping opacity-30 pointer-events-none" />
          )}
          <button
            onClick={onToggleMic}
            className={`w-14 h-14 rounded-full flex items-center justify-center transition-all shadow-xl ${
              isListening
                ? 'bg-gradient-to-tr from-cyan-400 to-blue-500 text-black hover:brightness-110 ring-4 ring-cyan-500/20'
                : 'bg-[#282a2c] text-red-400 hover:bg-[#333537]'
            }`}
            title={isListening ? 'Mute Microphone' : 'Unmute Microphone'}
          >
            {isListening ? <Mic className="w-6 h-6 stroke-[2.2]" /> : <MicOff className="w-6 h-6" />}
          </button>
        </div>

        {/* Exit Button */}
        <button
          onClick={onClose}
          className="px-5 py-3 rounded-full bg-[#1e1f20] hover:bg-[#282a2c] text-[#e3e3e3] border border-[#3c4043] text-xs font-medium transition-all"
        >
          Close Voice HUD
        </button>
      </div>
    </div>
  );
};
