import React from 'react';

export const JarvisSparkleIcon: React.FC<{
  className?: string;
  size?: number;
  animate?: boolean;
}> = ({ className = 'w-6 h-6', size, animate = false }) => {
  return (
    <svg
      viewBox="0 0 28 28"
      fill="none"
      xmlns="http://www.w3.org/2000/svg"
      className={`${className} ${animate ? 'animate-pulse' : ''}`}
      style={size ? { width: size, height: size } : undefined}
    >
      <defs>
        <linearGradient id="jarvisGrad" x1="0%" y1="0%" x2="100%" y2="100%">
          <stop offset="0%" stopColor="#38bdf8" />
          <stop offset="35%" stopColor="#818cf8" />
          <stop offset="70%" stopColor="#c084fc" />
          <stop offset="100%" stopColor="#2563eb" />
        </linearGradient>
        <radialGradient id="jarvisGlow" cx="50%" cy="50%" r="50%">
          <stop offset="0%" stopColor="#38bdf8" stopOpacity="0.9" />
          <stop offset="60%" stopColor="#818cf8" stopOpacity="0.4" />
          <stop offset="100%" stopColor="#3b82f6" stopOpacity="0" />
        </radialGradient>
      </defs>
      {animate && (
        <circle cx="14" cy="14" r="12" fill="url(#jarvisGlow)" className="animate-ping opacity-40" />
      )}
      <path
        d="M14 0C14 7.73199 7.73199 14 0 14C7.73199 14 14 20.268 14 28C14 20.268 20.268 14 28 14C20.268 14 14 7.73199 14 0Z"
        fill="url(#jarvisGrad)"
      />
    </svg>
  );
};

// Alias for backwards compatibility
export const GeminiSparkleIcon = JarvisSparkleIcon;

export const JarvisWordmark: React.FC<{ className?: string }> = ({ className = '' }) => {
  return (
    <div className={`flex items-center gap-2 select-none ${className}`}>
      <JarvisSparkleIcon className="w-5 h-5" />
      <span className="font-['Google_Sans',sans-serif] font-medium text-[20px] tracking-tight text-white flex items-center gap-1.5">
        Jarvis
        <span className="text-[10px] font-bold uppercase tracking-wider px-2 py-0.5 rounded-full bg-gradient-to-r from-cyan-500/20 via-blue-500/20 to-purple-500/20 text-[#38bdf8] border border-cyan-500/30 shadow-xs">
          AI
        </span>
      </span>
    </div>
  );
};

export const GeminiWordmark = JarvisWordmark;
