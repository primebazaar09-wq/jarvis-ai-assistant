import React, { useState } from 'react';
import {
  Plus,
  MessageSquare,
  Pin,
  Trash2,
  Settings,
  HelpCircle,
  Menu,
  ChevronRight,
  Radio,
  Eraser,
  Layers,
  Sparkles,
} from 'lucide-react';
import { ChatSession, AISystemType, AI_SYSTEMS } from '../types';

interface SidebarProps {
  isOpen: boolean;
  onToggle: () => void;
  sessions: ChatSession[];
  activeSessionId: string;
  onSelectSession: (id: string) => void;
  onNewChat: () => void;
  onDeleteSession: (id: string) => void;
  onTogglePinSession: (id: string) => void;
  onOpenSettings: () => void;
  wakeWordActive: boolean;
  onToggleWakeWord: () => void;
  onOpenLiveVoice: () => void;
  onClearConversation: () => void;
  onOpenStarkEcosystem: () => void;
  activeAISystem: AISystemType;
}

export const Sidebar: React.FC<SidebarProps> = ({
  isOpen,
  onToggle,
  sessions,
  activeSessionId,
  onSelectSession,
  onNewChat,
  onDeleteSession,
  onTogglePinSession,
  onOpenSettings,
  wakeWordActive,
  onToggleWakeWord,
  onOpenLiveVoice,
  onClearConversation,
  onOpenStarkEcosystem,
  activeAISystem,
}) => {
  const [hoveredId, setHoveredId] = useState<string | null>(null);
  const [confirmClear, setConfirmClear] = useState(false);

  const pinnedSessions = sessions.filter((s) => s.pinned);
  const recentSessions = sessions.filter((s) => !s.pinned);
  const activeSession = sessions.find((s) => s.id === activeSessionId) || sessions[0];
  const activeSessionHasMessages = activeSession && activeSession.messages.length > 0;
  const currentSysInfo = AI_SYSTEMS[activeAISystem];

  return (
    <>
      {/* Mobile Backdrop */}
      {isOpen && (
        <div
          className="fixed inset-0 z-40 bg-black/60 backdrop-blur-xs md:hidden"
          onClick={onToggle}
          aria-hidden="true"
        />
      )}

      {/* Main Sidebar Panel */}
      <aside
        className={`fixed md:static inset-y-0 left-0 z-50 flex flex-col justify-between bg-[#1e1f20] text-[#e3e3e3] border-r border-[#3c4043]/40 transition-all duration-300 ease-in-out select-none ${
          isOpen ? 'w-72 translate-x-0' : 'w-18 -translate-x-full md:translate-x-0'
        }`}
      >
        {/* Top Section */}
        <div className="p-3 flex flex-col gap-2.5">
          {/* Header Toggle & Status Badge */}
          <div className="flex items-center justify-between px-1 h-10">
            <button
              onClick={onToggle}
              className="p-2 rounded-full hover:bg-[#333537] text-[#c4c7c5] hover:text-white transition-colors"
              title={isOpen ? 'Collapse menu' : 'Expand menu'}
              aria-label="Collapse menu"
            >
              <Menu className="w-5 h-5" />
            </button>
            {isOpen && (
              <span className="text-xs font-semibold px-2.5 py-1 rounded-full bg-gradient-to-r from-cyan-500/10 to-blue-500/10 text-[#38bdf8] border border-cyan-500/20 flex items-center gap-1.5">
                <span className="w-1.5 h-1.5 rounded-full bg-cyan-400 animate-pulse" />
                {currentSysInfo.name} Active
              </span>
            )}
          </div>

          {/* New Chat Button */}
          <button
            onClick={onNewChat}
            className={`flex items-center gap-3 py-3 px-4 rounded-full bg-[#282a2c] hover:bg-[#333537] text-[#e3e3e3] transition-all shadow-xs border border-[#3c4043]/30 group ${
              isOpen ? 'justify-start w-full' : 'justify-center w-11 h-11 p-0 mx-auto'
            }`}
            title="New chat"
          >
            <Plus className="w-5 h-5 text-cyan-400 group-hover:rotate-90 transition-transform duration-200" />
            {isOpen && <span className="text-sm font-medium">New chat</span>}
          </button>

          {/* Live Voice Quick Action */}
          {isOpen ? (
            <button
              onClick={onOpenLiveVoice}
              className="flex items-center justify-between p-3 rounded-2xl bg-gradient-to-r from-cyan-600/20 via-blue-600/20 to-indigo-600/20 hover:from-cyan-600/30 hover:to-indigo-600/30 border border-cyan-500/30 text-white transition-all shadow-xs"
            >
              <div className="flex items-center gap-2.5">
                <div className="w-8 h-8 rounded-full bg-gradient-to-tr from-cyan-400 to-blue-500 flex items-center justify-center shadow-md">
                  <Radio className="w-4 h-4 text-white animate-pulse" />
                </div>
                <div className="text-left">
                  <div className="text-xs font-semibold">{currentSysInfo.name} Live Voice</div>
                  <div className="text-[11px] text-[#38bdf8]">Hands-free mode</div>
                </div>
              </div>
              <ChevronRight className="w-4 h-4 text-cyan-300" />
            </button>
          ) : (
            <button
              onClick={onOpenLiveVoice}
              className="w-11 h-11 mx-auto rounded-full bg-gradient-to-tr from-cyan-600/40 to-blue-600/40 hover:from-cyan-600/60 hover:to-blue-600/60 border border-cyan-500/30 flex items-center justify-center text-cyan-400 transition-colors"
              title={`${currentSysInfo.name} Live Voice`}
            >
              <Radio className="w-4 h-4" />
            </button>
          )}

          {/* Clear Conversation Option for Active Session */}
          {isOpen && activeSessionHasMessages && (
            <div>
              {confirmClear ? (
                <div className="flex items-center justify-between p-2.5 rounded-xl bg-red-950/40 border border-red-500/40 text-xs animate-in fade-in duration-150">
                  <span className="text-red-200 font-medium">Wipe conversation?</span>
                  <div className="flex items-center gap-1.5">
                    <button
                      onClick={() => {
                        onClearConversation();
                        setConfirmClear(false);
                      }}
                      className="px-2.5 py-1 rounded-lg bg-red-600 hover:bg-red-500 text-white font-semibold text-[11px] shadow-xs"
                      title="Confirm clear"
                    >
                      Clear
                    </button>
                    <button
                      onClick={() => setConfirmClear(false)}
                      className="px-2 py-1 rounded-lg bg-[#282a2c] text-[#c4c7c5] hover:text-white text-[11px]"
                    >
                      Cancel
                    </button>
                  </div>
                </div>
              ) : (
                <button
                  onClick={() => setConfirmClear(true)}
                  className="w-full flex items-center gap-2.5 px-3 py-2 rounded-xl text-xs font-medium text-[#c4c7c5] hover:text-red-300 hover:bg-red-500/10 border border-[#3c4043]/40 hover:border-red-500/30 transition-colors group"
                  title="Wipe conversation messages without deleting this chat session"
                >
                  <Eraser className="w-4 h-4 text-[#9aa0a6] group-hover:text-red-400 transition-colors" />
                  <span>Clear Conversation</span>
                </button>
              )}
            </div>
          )}
        </div>

        {/* Chat History List */}
        <div className="flex-1 overflow-y-auto px-3 py-2 space-y-4 scrollbar-thin scrollbar-thumb-[#3c4043]">
          {isOpen && (
            <>
              {/* Pinned Chats */}
              {pinnedSessions.length > 0 && (
                <div>
                  <div className="text-[11px] font-semibold uppercase tracking-wider text-[#9aa0a6] px-3 mb-1 flex items-center gap-1.5">
                    <Pin className="w-3 h-3 text-cyan-400" />
                    Pinned
                  </div>
                  <div className="space-y-1">
                    {pinnedSessions.map((session) => (
                      <SessionItem
                        key={session.id}
                        session={session}
                        isActive={session.id === activeSessionId}
                        isHovered={hoveredId === session.id}
                        onHover={setHoveredId}
                        onSelect={() => onSelectSession(session.id)}
                        onDelete={() => onDeleteSession(session.id)}
                        onTogglePin={() => onTogglePinSession(session.id)}
                      />
                    ))}
                  </div>
                </div>
              )}

              {/* Recent Chats */}
              <div>
                <div className="text-[11px] font-semibold uppercase tracking-wider text-[#9aa0a6] px-3 mb-1">
                  Recent
                </div>
                {recentSessions.length === 0 && pinnedSessions.length === 0 ? (
                  <div className="text-xs text-[#9aa0a6] px-3 py-2 italic">
                    No conversations yet
                  </div>
                ) : (
                  <div className="space-y-1">
                    {recentSessions.map((session) => (
                      <SessionItem
                        key={session.id}
                        session={session}
                        isActive={session.id === activeSessionId}
                        isHovered={hoveredId === session.id}
                        onHover={setHoveredId}
                        onSelect={() => onSelectSession(session.id)}
                        onDelete={() => onDeleteSession(session.id)}
                        onTogglePin={() => onTogglePinSession(session.id)}
                      />
                    ))}
                  </div>
                )}
              </div>
            </>
          )}
        </div>

        {/* Bottom Section: Stark Ecosystem, Wake Word Toggle, Settings, Profile */}
        <div className="p-3 border-t border-[#3c4043]/40 flex flex-col gap-1.5">
          {/* Stark AI Systems Ecosystem Button */}
          <button
            onClick={onOpenStarkEcosystem}
            className={`flex items-center gap-3 p-2.5 rounded-xl hover:bg-[#333537] text-[#c4c7c5] hover:text-white transition-colors border border-cyan-500/20 bg-gradient-to-r from-cyan-950/20 to-blue-950/20 ${
              isOpen ? 'w-full justify-between' : 'w-11 h-11 justify-center mx-auto'
            }`}
            title="Mahesh's AI Systems: JARVIS, FRIDAY, E.D.I.T.H."
          >
            <div className="flex items-center gap-3">
              <Layers className="w-5 h-5 text-cyan-400" />
              {isOpen && (
                <div className="text-left">
                  <div className="text-xs font-semibold text-white flex items-center gap-1.5">
                    Stark AI Systems
                    <span className="text-[9px] uppercase px-1 rounded bg-cyan-400/20 text-cyan-300">
                      3 AIs
                    </span>
                  </div>
                  <div className="text-[10px] text-[#9aa0a6]">
                    JARVIS • FRIDAY • E.D.I.T.H.
                  </div>
                </div>
              )}
            </div>
            {isOpen && <ChevronRight className="w-4 h-4 text-[#9aa0a6]" />}
          </button>

          {/* Wake Word Status */}
          {isOpen ? (
            <div className="flex items-center justify-between px-3 py-2 rounded-xl bg-[#282a2c]/60 text-xs">
              <div className="flex items-center gap-2">
                <span
                  className={`w-2 h-2 rounded-full ${
                    wakeWordActive ? 'bg-emerald-400 animate-pulse' : 'bg-zinc-500'
                  }`}
                />
                <span className="text-[#c4c7c5]">"Hey {currentSysInfo.name}" Wake Word</span>
              </div>
              <button
                onClick={onToggleWakeWord}
                className={`text-[11px] font-medium px-2 py-0.5 rounded-full transition-colors ${
                  wakeWordActive
                    ? 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/30'
                    : 'bg-zinc-700 text-zinc-300'
                }`}
              >
                {wakeWordActive ? 'ON' : 'OFF'}
              </button>
            </div>
          ) : (
            <button
              onClick={onToggleWakeWord}
              className={`w-11 h-11 mx-auto rounded-full flex items-center justify-center transition-colors ${
                wakeWordActive ? 'bg-emerald-500/20 text-emerald-400' : 'text-zinc-400 hover:bg-[#282a2c]'
              }`}
              title={`Wake Word: ${wakeWordActive ? 'ON' : 'OFF'}`}
            >
              <span
                className={`w-2.5 h-2.5 rounded-full ${
                  wakeWordActive ? 'bg-emerald-400 animate-pulse' : 'bg-zinc-500'
                }`}
              />
            </button>
          )}

          {/* Settings Button */}
          <button
            onClick={onOpenSettings}
            className={`flex items-center gap-3 p-2.5 rounded-xl hover:bg-[#333537] text-[#c4c7c5] hover:text-white transition-colors ${
              isOpen ? 'w-full' : 'w-11 h-11 justify-center mx-auto'
            }`}
            title="Settings"
          >
            <Settings className="w-5 h-5" />
            {isOpen && <span className="text-sm font-medium">Settings & Voices</span>}
          </button>

          {/* Help & Activity */}
          <a
            href="https://google.com"
            target="_blank"
            rel="noopener noreferrer"
            className={`flex items-center gap-3 p-2.5 rounded-xl hover:bg-[#333537] text-[#c4c7c5] hover:text-white transition-colors ${
              isOpen ? 'w-full' : 'w-11 h-11 justify-center mx-auto'
            }`}
            title="Help & Activity"
          >
            <HelpCircle className="w-5 h-5" />
            {isOpen && <span className="text-sm font-medium">Help & Activity</span>}
          </a>

          {/* User Profile */}
          <div
            className={`flex items-center gap-3 p-2 rounded-xl mt-1 ${
              isOpen ? 'w-full' : 'justify-center'
            }`}
          >
            <div className="w-8 h-8 rounded-full bg-gradient-to-tr from-cyan-500 to-indigo-500 text-white font-medium text-xs flex items-center justify-center shadow-sm">
              P
            </div>
            {isOpen && (
              <div className="truncate text-left">
                <div className="text-xs font-medium text-[#e3e3e3] truncate">
                  pmjoya123@gmail.com
                </div>
                <div className="text-[10px] text-[#38bdf8]">
                  {currentSysInfo.name} Advanced
                </div>
              </div>
            )}
          </div>
        </div>
      </aside>
    </>
  );
};

interface SessionItemProps {
  session: ChatSession;
  isActive: boolean;
  isHovered: boolean;
  onHover: (id: string | null) => void;
  onSelect: () => void;
  onDelete: () => void;
  onTogglePin: () => void;
}

const SessionItem: React.FC<SessionItemProps> = ({
  session,
  isActive,
  isHovered,
  onHover,
  onSelect,
  onDelete,
  onTogglePin,
}) => {
  return (
    <div
      onMouseEnter={() => onHover(session.id)}
      onMouseLeave={() => onHover(null)}
      onClick={onSelect}
      className={`group relative flex items-center justify-between px-3 py-2 rounded-xl cursor-pointer text-xs transition-colors ${
        isActive
          ? 'bg-[#004a77]/60 text-white font-medium border border-cyan-500/30'
          : 'hover:bg-[#282a2c] text-[#c4c7c5] hover:text-[#e3e3e3]'
      }`}
    >
      <div className="flex items-center gap-2.5 truncate flex-1 mr-2">
        <MessageSquare
          className={`w-4 h-4 shrink-0 ${
            isActive ? 'text-cyan-400' : 'text-[#9aa0a6] group-hover:text-white'
          }`}
        />
        <span className="truncate">{session.title || 'New chat'}</span>
      </div>

      {/* Action Icons: Pin & Delete on hover or active */}
      <div
        className={`flex items-center gap-0.5 shrink-0 transition-opacity ${
          isHovered || isActive ? 'opacity-100' : 'opacity-0'
        }`}
        onClick={(e) => e.stopPropagation()}
      >
        <button
          onClick={onTogglePin}
          className={`p-1 rounded-md hover:bg-[#333537] transition-colors ${
            session.pinned ? 'text-cyan-400' : 'text-[#9aa0a6] hover:text-white'
          }`}
          title={session.pinned ? 'Unpin' : 'Pin'}
        >
          <Pin className="w-3.5 h-3.5" />
        </button>
        <button
          onClick={onDelete}
          className="p-1 rounded-md hover:bg-red-500/20 text-[#9aa0a6] hover:text-red-400 transition-colors"
          title="Delete chat"
        >
          <Trash2 className="w-3.5 h-3.5" />
        </button>
      </div>
    </div>
  );
};
