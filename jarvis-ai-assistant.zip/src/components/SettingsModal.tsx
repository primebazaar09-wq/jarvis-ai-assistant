import React, { useState } from 'react';
import {
  X,
  Volume2,
  Mic,
  Sliders,
  Check,
  Plus,
  Play,
  RotateCcw,
  Sparkles,
} from 'lucide-react';
import { VoiceSettings } from '../types';
import { speakText, stopSpeaking } from '../utils/speechManager';

interface SettingsModalProps {
  isOpen: boolean;
  onClose: () => void;
  settings: VoiceSettings;
  onUpdateSettings: (newSettings: Partial<VoiceSettings>) => void;
}

export const SettingsModal: React.FC<SettingsModalProps> = ({
  isOpen,
  onClose,
  settings,
  onUpdateSettings,
}) => {
  const [newWakeWord, setNewWakeWord] = useState('');
  const [isTestingVoice, setIsTestingVoice] = useState(false);

  if (!isOpen) return null;

  const handleTestVoice = async (voice: string) => {
    setIsTestingVoice(true);
    await speakText(
      `Hello! I am Jarvis, your hands-free voice AI assistant. How can I assist you today?`,
      voice,
      undefined,
      () => setIsTestingVoice(false)
    );
  };

  const handleAddWakeWord = () => {
    const trimmed = newWakeWord.trim().toLowerCase();
    if (trimmed && !settings.wakeWords.includes(trimmed)) {
      onUpdateSettings({
        wakeWords: [...settings.wakeWords, trimmed],
      });
      setNewWakeWord('');
    }
  };

  const handleRemoveWakeWord = (word: string) => {
    onUpdateSettings({
      wakeWords: settings.wakeWords.filter((w) => w !== word),
    });
  };

  return (
    <div
      role="dialog"
      aria-modal="true"
      aria-label="Assistant and Voice Settings"
      className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/70 backdrop-blur-xs select-none animate-in fade-in duration-200"
    >
      <div className="w-full max-w-lg rounded-3xl bg-[#1e1f20] border border-[#3c4043] shadow-2xl overflow-hidden flex flex-col max-h-[90vh]">
        {/* Header */}
        <div className="flex items-center justify-between px-6 py-4 border-b border-[#3c4043]/50">
          <div className="flex items-center gap-2.5">
            <Sliders className="w-5 h-5 text-[#8ab4f8]" />
            <h2 className="font-['Google_Sans',sans-serif] font-medium text-lg text-white">
              Jarvis Voice & Intelligence Settings
            </h2>
          </div>
          <button
            onClick={() => {
              stopSpeaking();
              onClose();
            }}
            className="p-1.5 rounded-full hover:bg-[#282a2c] text-[#9aa0a6] hover:text-white transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Content */}
        <div className="flex-1 overflow-y-auto p-6 space-y-6">
          {/* Wake Word Detection Section */}
          <div className="space-y-3">
            <div className="flex items-center justify-between">
              <div>
                <label className="text-sm font-semibold text-white flex items-center gap-2">
                  <Mic className="w-4 h-4 text-emerald-400" />
                  Hands-Free Wake Word Listening
                </label>
                <p className="text-xs text-[#9aa0a6] mt-0.5">
                  Continuously listen for "Hey Jarvis" in the background
                </p>
              </div>
              <input
                type="checkbox"
                checked={settings.wakeWordEnabled}
                onChange={(e) => onUpdateSettings({ wakeWordEnabled: e.target.checked })}
                className="w-5 h-5 rounded accent-[#8ab4f8] cursor-pointer"
              />
            </div>

            {/* Wake Word List */}
            <div className="mt-2 p-3 rounded-2xl bg-[#131314] border border-[#3c4043]/40 space-y-2">
              <span className="text-[11px] font-semibold text-[#9aa0a6] uppercase tracking-wider block">
                Recognized Wake Phrases
              </span>
              <div className="flex flex-wrap gap-2">
                {settings.wakeWords.map((word) => (
                  <span
                    key={word}
                    className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-medium bg-[#282a2c] text-[#c4c7c5] border border-[#3c4043]"
                  >
                    "{word}"
                    {settings.wakeWords.length > 1 && (
                      <button
                        onClick={() => handleRemoveWakeWord(word)}
                        className="text-[#9aa0a6] hover:text-red-400"
                        title="Remove"
                      >
                        ×
                      </button>
                    )}
                  </span>
                ))}
              </div>

              {/* Add Custom Wake Word */}
              <div className="flex items-center gap-2 pt-1">
                <input
                  type="text"
                  value={newWakeWord}
                  onChange={(e) => setNewWakeWord(e.target.value)}
                  onKeyDown={(e) => e.key === 'Enter' && handleAddWakeWord()}
                  placeholder="Add phrase (e.g. 'Computer')..."
                  className="flex-1 px-3 py-1.5 rounded-xl bg-[#282a2c] text-xs text-white border border-[#3c4043] focus:border-[#8ab4f8] outline-none"
                />
                <button
                  onClick={handleAddWakeWord}
                  disabled={!newWakeWord.trim()}
                  className="px-3 py-1.5 rounded-xl bg-[#8ab4f8]/20 text-[#8ab4f8] hover:bg-[#8ab4f8]/30 disabled:opacity-50 text-xs font-semibold flex items-center gap-1"
                >
                  <Plus className="w-3.5 h-3.5" />
                  Add
                </button>
              </div>
            </div>
          </div>

          {/* Voice Personality & Jarvis TTS */}
          <div className="space-y-3 pt-3 border-t border-[#3c4043]/40">
            <div>
              <label className="text-sm font-semibold text-white flex items-center gap-2">
                <Volume2 className="w-4 h-4 text-cyan-400" />
                Jarvis Spoken Voice Persona
              </label>
              <p className="text-xs text-[#9aa0a6] mt-0.5">
                Neural text-to-speech voice model for Jarvis
              </p>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
              {[
                { name: 'Zephyr', desc: 'Warm, dynamic & expressive' },
                { name: 'Kore', desc: 'Calm, soothing & clear' },
                { name: 'Fenrir', desc: 'Deep, resonant & authoritative' },
                { name: 'Puck', desc: 'Engaging, witty & crisp' },
                { name: 'Charon', desc: 'Direct, focused & concise' },
              ].map((v) => (
                <div
                  key={v.name}
                  onClick={() => onUpdateSettings({ voiceName: v.name as any })}
                  className={`p-3 rounded-xl border text-left cursor-pointer transition-all flex items-center justify-between ${
                    settings.voiceName === v.name
                      ? 'bg-[#004a77]/40 border-[#8ab4f8] text-white'
                      : 'bg-[#131314] border-[#3c4043]/40 text-[#c4c7c5] hover:bg-[#282a2c]'
                  }`}
                >
                  <div>
                    <div className="text-xs font-semibold flex items-center gap-1.5">
                      {v.name}
                      {settings.voiceName === v.name && (
                        <Check className="w-3.5 h-3.5 text-[#8ab4f8]" />
                      )}
                    </div>
                    <div className="text-[11px] text-[#9aa0a6]">{v.desc}</div>
                  </div>
                  <button
                    onClick={(e) => {
                      e.stopPropagation();
                      handleTestVoice(v.name);
                    }}
                    className="p-1.5 rounded-full hover:bg-white/10 text-[#8ab4f8]"
                    title={`Preview ${v.name} voice`}
                  >
                    <Play className="w-3.5 h-3.5 fill-current" />
                  </button>
                </div>
              ))}
            </div>
          </div>

          {/* Behavior Toggles */}
          <div className="space-y-4 pt-3 border-t border-[#3c4043]/40">
            <div className="flex items-center justify-between">
              <div>
                <div className="text-sm font-medium text-white">Auto-speak responses</div>
                <div className="text-xs text-[#9aa0a6]">
                  Jarvis speaks answers aloud immediately upon completion
                </div>
              </div>
              <input
                type="checkbox"
                checked={settings.autoSpeakResponse}
                onChange={(e) => onUpdateSettings({ autoSpeakResponse: e.target.checked })}
                className="w-5 h-5 rounded accent-[#8ab4f8] cursor-pointer"
              />
            </div>

            <div className="flex items-center justify-between">
              <div>
                <div className="text-sm font-medium text-white">Continuous conversation</div>
                <div className="text-xs text-[#9aa0a6]">
                  Automatically listen for follow-up questions after Jarvis finishes speaking
                </div>
              </div>
              <input
                type="checkbox"
                checked={settings.continuousConversation}
                onChange={(e) =>
                  onUpdateSettings({ continuousConversation: e.target.checked })
                }
                className="w-5 h-5 rounded accent-[#8ab4f8] cursor-pointer"
              />
            </div>
          </div>
        </div>

        {/* Footer */}
        <div className="px-6 py-4 border-t border-[#3c4043]/50 flex justify-end">
          <button
            onClick={() => {
              stopSpeaking();
              onClose();
            }}
            className="px-5 py-2 rounded-full bg-white text-black hover:bg-zinc-200 text-xs font-semibold transition-colors"
          >
            Done
          </button>
        </div>
      </div>
    </div>
  );
};
