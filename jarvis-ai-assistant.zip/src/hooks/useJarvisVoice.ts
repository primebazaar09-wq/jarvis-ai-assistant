import { useState, useEffect, useRef, useCallback } from 'react';
import { extractWakeWordCommand, playChime } from '../utils/wakeWordDetector';

interface UseJarvisVoiceProps {
  wakeWords: string[];
  enabled: boolean;
  onCommand: (command: string) => void;
  autoSpeak: boolean;
}

export function useJarvisVoice({
  wakeWords,
  enabled,
  onCommand,
}: UseJarvisVoiceProps) {
  const [isListening, setIsListening] = useState(false);
  const [isAwake, setIsAwake] = useState(false); // True when "Hey Jarvis" has been triggered
  const [isDirectListening, setIsDirectListening] = useState(false); // Direct speech-to-text mode
  const [transcript, setTranscript] = useState('');
  const [interimText, setInterimText] = useState('');
  const [audioLevel, setAudioLevel] = useState(0);
  const [audioSpectrum, setAudioSpectrum] = useState<number[]>([10, 15, 25, 30, 20, 15, 10, 8]);
  const [micPermission, setMicPermission] = useState<'granted' | 'denied' | 'prompt'>('prompt');
  const [supported, setSupported] = useState(true);

  const recognitionRef = useRef<any>(null);
  const isAwakeRef = useRef(false);
  const isDirectListeningRef = useRef(false);
  const enabledRef = useRef(enabled);
  const wakeWordsRef = useRef(wakeWords);
  const onCommandRef = useRef(onCommand);
  const commandTimeoutRef = useRef<any>(null);
  const restartTimeoutRef = useRef<any>(null);
  const audioContextRef = useRef<AudioContext | null>(null);
  const analyserRef = useRef<AnalyserNode | null>(null);
  const mediaStreamRef = useRef<MediaStream | null>(null);
  const animFrameRef = useRef<number | null>(null);

  isAwakeRef.current = isAwake;
  isDirectListeningRef.current = isDirectListening;
  enabledRef.current = enabled;
  wakeWordsRef.current = wakeWords;
  onCommandRef.current = onCommand;

  // Initialize Speech Recognition
  useEffect(() => {
    const SpeechRecognition =
      (window as any).SpeechRecognition || (window as any).webkitSpeechRecognition;

    if (!SpeechRecognition) {
      setSupported(false);
      return;
    }

    try {
      const recognition = new SpeechRecognition();
      recognition.continuous = true;
      recognition.interimResults = true;
      recognition.lang = 'en-US';
      recognition.maxAlternatives = 1;

      recognition.onstart = () => {
        setIsListening(true);
        setMicPermission('granted');
      };

      recognition.onend = () => {
        setIsListening(false);
        // Automatically restart smoothly if enabled
        if (enabledRef.current || isDirectListeningRef.current) {
          clearTimeout(restartTimeoutRef.current);
          restartTimeoutRef.current = setTimeout(() => {
            try {
              recognition.start();
            } catch (e) {
              // already active
            }
          }, 200);
        }
      };

      recognition.onerror = (event: any) => {
        console.debug('Speech recognition status:', event.error);
        if (event.error === 'not-allowed') {
          setMicPermission('denied');
        }
      };

      recognition.onresult = (event: any) => {
        let finalSegment = '';
        let interimSegment = '';

        for (let i = event.resultIndex; i < event.results.length; ++i) {
          if (event.results[i].isFinal) {
            finalSegment += event.results[i][0].transcript;
          } else {
            interimSegment += event.results[i][0].transcript;
          }
        }

        const currentText = (finalSegment || interimSegment).trim();
        setInterimText(currentText);

        if (!currentText) return;

        // If direct listening or Jarvis is already awake, treat speech as the command
        if (isAwakeRef.current || isDirectListeningRef.current) {
          setTranscript(currentText);

          if (commandTimeoutRef.current) clearTimeout(commandTimeoutRef.current);

          commandTimeoutRef.current = setTimeout(() => {
            const detectedCmd = currentText;
            if (detectedCmd.length > 1) {
              playChime('success');
              setIsAwake(false);
              setIsDirectListening(false);
              setTranscript('');
              setInterimText('');
              onCommandRef.current(detectedCmd);
            }
          }, 1200);
          return;
        }

        // Check for wake word in incoming transcript
        const detection = extractWakeWordCommand(currentText, wakeWordsRef.current);
        if (detection.detected) {
          playChime('wake');
          setIsAwake(true);

          if (detection.isDirectCommand && detection.command.length > 2) {
            // Spoken in one breath: "Hey Jarvis, [command]"
            setTranscript(detection.command);
            if (commandTimeoutRef.current) clearTimeout(commandTimeoutRef.current);
            commandTimeoutRef.current = setTimeout(() => {
              playChime('success');
              setIsAwake(false);
              setTranscript('');
              setInterimText('');
              onCommandRef.current(detection.command);
            }, 900);
          } else {
            // Wake word triggered, listen for subsequent command
            setTranscript('Listening for command...');
            if (commandTimeoutRef.current) clearTimeout(commandTimeoutRef.current);
            commandTimeoutRef.current = setTimeout(() => {
              if (isAwakeRef.current) {
                setIsAwake(false);
                setTranscript('');
                setInterimText('');
              }
            }, 8000);
          }
        }
      };

      recognitionRef.current = recognition;
    } catch (err) {
      console.error('Error initializing speech recognition:', err);
      setSupported(false);
    }

    return () => {
      clearTimeout(commandTimeoutRef.current);
      clearTimeout(restartTimeoutRef.current);
      if (recognitionRef.current) {
        try {
          recognitionRef.current.stop();
        } catch (e) {
          // ignore
        }
      }
    };
  }, []);

  // Handle start / stop listening
  useEffect(() => {
    if (!recognitionRef.current) return;

    if (enabled || isDirectListening) {
      try {
        recognitionRef.current.start();
      } catch (err) {
        // Recognition already running
      }
    } else {
      try {
        recognitionRef.current.stop();
        setIsAwake(false);
      } catch (err) {
        // ignore
      }
    }
  }, [enabled, isDirectListening]);

  // Audio level and frequency spectrum analyzer
  const startAudioMeter = useCallback(async () => {
    try {
      if (mediaStreamRef.current) {
        mediaStreamRef.current.getTracks().forEach((t) => t.stop());
      }

      const stream = await navigator.mediaDevices.getUserMedia({
        audio: {
          echoCancellation: true,
          noiseSuppression: true,
          autoGainControl: true,
        },
      });
      mediaStreamRef.current = stream;

      const AudioCtx = window.AudioContext || (window as any).webkitAudioContext;
      const ctx = new AudioCtx();
      const analyser = ctx.createAnalyser();
      analyser.fftSize = 64;
      analyser.smoothingTimeConstant = 0.6;
      const source = ctx.createMediaStreamSource(stream);
      source.connect(analyser);

      audioContextRef.current = ctx;
      analyserRef.current = analyser;

      const dataArray = new Uint8Array(analyser.frequencyBinCount);

      const updateLevel = () => {
        if (!analyserRef.current) return;
        analyserRef.current.getByteFrequencyData(dataArray);

        let sum = 0;
        const spectrumSlice: number[] = [];
        const step = Math.floor(dataArray.length / 8);

        for (let i = 0; i < 8; i++) {
          let bandSum = 0;
          for (let j = 0; j < step; j++) {
            bandSum += dataArray[i * step + j] || 0;
          }
          const bandAvg = bandSum / step;
          spectrumSlice.push(Math.round((bandAvg / 255) * 100));
        }

        for (let i = 0; i < dataArray.length; i++) {
          sum += dataArray[i];
        }

        const avg = sum / dataArray.length;
        setAudioLevel(Math.min(100, Math.round((avg / 255) * 100)));
        setAudioSpectrum(spectrumSlice);

        animFrameRef.current = requestAnimationFrame(updateLevel);
      };

      updateLevel();
      setMicPermission('granted');
    } catch (err) {
      console.debug('Microphone meter info:', err);
    }
  }, []);

  useEffect(() => {
    if (enabled || isDirectListening) {
      startAudioMeter();
    } else {
      if (animFrameRef.current) cancelAnimationFrame(animFrameRef.current);
      if (audioContextRef.current) {
        audioContextRef.current.close().catch(() => {});
        audioContextRef.current = null;
      }
      if (mediaStreamRef.current) {
        mediaStreamRef.current.getTracks().forEach((t) => t.stop());
        mediaStreamRef.current = null;
      }
      setAudioLevel(0);
      setAudioSpectrum([4, 6, 8, 12, 8, 6, 4, 3]);
    }
    return () => {
      if (animFrameRef.current) cancelAnimationFrame(animFrameRef.current);
      if (audioContextRef.current) {
        audioContextRef.current.close().catch(() => {});
        audioContextRef.current = null;
      }
      if (mediaStreamRef.current) {
        mediaStreamRef.current.getTracks().forEach((t) => t.stop());
        mediaStreamRef.current = null;
      }
    };
  }, [enabled, isDirectListening, startAudioMeter]);

  // Direct Push-to-Talk activation
  const startDirectListening = useCallback(() => {
    playChime('wake');
    setIsAwake(true);
    setIsDirectListening(true);
    setTranscript('Listening to your voice...');
    try {
      recognitionRef.current?.start();
    } catch (e) {
      // already active
    }
  }, []);

  // Manual trigger / simulation for testing or button clicks
  const triggerWakeWord = useCallback((customPrompt?: string) => {
    playChime('wake');
    setIsAwake(true);
    setTranscript(customPrompt || 'Listening for your command...');

    if (customPrompt) {
      setTimeout(() => {
        playChime('success');
        setIsAwake(false);
        setIsDirectListening(false);
        setTranscript('');
        onCommandRef.current(customPrompt);
      }, 700);
    }
  }, []);

  const dismissAwake = useCallback(() => {
    setIsAwake(false);
    setIsDirectListening(false);
    setTranscript('');
    setInterimText('');
  }, []);

  return {
    isListening,
    isAwake,
    isDirectListening,
    transcript,
    interimText,
    audioLevel,
    audioSpectrum,
    micPermission,
    supported,
    triggerWakeWord,
    startDirectListening,
    dismissAwake,
  };
}
