/**
 * Wake Word and Speech Utilities for Hands-Free Jarvis Voice Assistance
 */

export interface WakeWordResult {
  detected: boolean;
  wakeWordMatched: string | null;
  command: string;
  isDirectCommand: boolean;
}

export const DEFAULT_WAKE_WORDS = [
  // JARVIS
  'hey jarvis',
  'ok jarvis',
  'okay jarvis',
  'hi jarvis',
  'hello jarvis',
  'jarvis',
  'yo jarvis',
  'wake up jarvis',
  // FRIDAY
  'hey friday',
  'ok friday',
  'okay friday',
  'hi friday',
  'hello friday',
  'friday',
  // E.D.I.T.H.
  'hey edith',
  'ok edith',
  'okay edith',
  'hi edith',
  'hello edith',
  'edith',
];

/**
 * Normalizes speech text by stripping surrounding punctuation, extra spaces,
 * and converting to lowercase.
 */
export function normalizeSpeech(text: string): string {
  if (!text) return '';
  return text
    .toLowerCase()
    .replace(/[.,/#!$%^&*;:{}=\-_`~()?]/g, ' ')
    .replace(/\s+/g, ' ')
    .trim();
}

/**
 * Checks if a transcript contains any configured wake words,
 * and extracts the ensuing command text.
 */
export function extractWakeWordCommand(
  rawTranscript: string,
  wakeWords: string[] = DEFAULT_WAKE_WORDS
): WakeWordResult {
  const normalized = normalizeSpeech(rawTranscript);
  if (!normalized) {
    return {
      detected: false,
      wakeWordMatched: null,
      command: '',
      isDirectCommand: false,
    };
  }

  // Sort wake words by length descending so longer phrases match first ("hey jarvis" before "jarvis")
  const sortedWakeWords = [...wakeWords].sort((a, b) => b.length - a.length);

  for (const phrase of sortedWakeWords) {
    const normPhrase = normalizeSpeech(phrase);
    if (!normPhrase) continue;

    // Check if the transcript starts with or contains the wake phrase
    const phraseIndex = normalized.indexOf(normPhrase);
    if (phraseIndex !== -1) {
      // Extract everything after the wake phrase
      const afterPhrase = normalized.slice(phraseIndex + normPhrase.length).trim();
      return {
        detected: true,
        wakeWordMatched: phrase,
        command: afterPhrase,
        isDirectCommand: afterPhrase.length > 0,
      };
    }
  }

  return {
    detected: false,
    wakeWordMatched: null,
    command: normalized,
    isDirectCommand: false,
  };
}

/**
 * Synthesizes an audio feedback chime using Web Audio API
 */
export function playChime(type: 'wake' | 'success' | 'listening' | 'error' = 'wake') {
  if (typeof window === 'undefined' || (!window.AudioContext && !(window as any).webkitAudioContext)) {
    return;
  }

  try {
    const AudioCtx = window.AudioContext || (window as any).webkitAudioContext;
    const ctx = new AudioCtx();
    const now = ctx.currentTime;

    if (type === 'wake') {
      // Pleasant futuristic dual-tone "Jarvis" activation chime
      const osc1 = ctx.createOscillator();
      const osc2 = ctx.createOscillator();
      const gain = ctx.createGain();

      osc1.type = 'sine';
      osc2.type = 'triangle';

      osc1.frequency.setValueAtTime(587.33, now); // D5
      osc1.frequency.exponentialRampToValueAtTime(880.00, now + 0.12); // A5

      osc2.frequency.setValueAtTime(880.00, now);
      osc2.frequency.exponentialRampToValueAtTime(1174.66, now + 0.12); // D6

      gain.gain.setValueAtTime(0.001, now);
      gain.gain.exponentialRampToValueAtTime(0.25, now + 0.04);
      gain.gain.exponentialRampToValueAtTime(0.0001, now + 0.35);

      osc1.connect(gain);
      osc2.connect(gain);
      gain.connect(ctx.destination);

      osc1.start(now);
      osc2.start(now);
      osc1.stop(now + 0.36);
      osc2.stop(now + 0.36);
    } else if (type === 'success') {
      // Smooth completion bell
      const osc = ctx.createOscillator();
      const gain = ctx.createGain();
      osc.type = 'sine';
      osc.frequency.setValueAtTime(659.25, now); // E5
      osc.frequency.exponentialRampToValueAtTime(1046.50, now + 0.15); // C6
      gain.gain.setValueAtTime(0.2, now);
      gain.gain.exponentialRampToValueAtTime(0.001, now + 0.3);
      osc.connect(gain);
      gain.connect(ctx.destination);
      osc.start(now);
      osc.stop(now + 0.3);
    } else if (type === 'error') {
      // Low gentle warning
      const osc = ctx.createOscillator();
      const gain = ctx.createGain();
      osc.type = 'sawtooth';
      osc.frequency.setValueAtTime(261.63, now); // C4
      osc.frequency.linearRampToValueAtTime(220, now + 0.2);
      gain.gain.setValueAtTime(0.15, now);
      gain.gain.exponentialRampToValueAtTime(0.001, now + 0.25);
      osc.connect(gain);
      gain.connect(ctx.destination);
      osc.start(now);
      osc.stop(now + 0.25);
    }
  } catch (err) {
    console.debug('Audio chime unable to play:', err);
  }
}
