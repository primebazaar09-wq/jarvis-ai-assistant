/**
 * Speech Manager for Text-to-Speech and Continuous Speech Recognition
 */

let currentAudio: HTMLAudioElement | null = null;

export async function speakText(
  text: string,
  voiceName: string = 'Zephyr',
  onStart?: () => void,
  onEnd?: () => void
): Promise<void> {
  // Stop any currently playing speech
  stopSpeaking();

  if (!text) return;

  // Clean markdown tags for spoken audio
  const spokenText = text
    .replace(/```[\s\S]*?```/g, ' Code snippet omitted. ')
    .replace(/`([^`]+)`/g, '$1')
    .replace(/[*_#>[\]()]/g, ' ')
    .replace(/\s+/g, ' ')
    .trim()
    .slice(0, 1000);

  if (!spokenText) return;

  onStart?.();

  try {
    // Attempt Gemini TTS first for rich natural AI voice
    const res = await fetch('/api/gemini/tts', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ text: spokenText, voiceName }),
    });

    if (res.ok) {
      const data = await res.json();
      if (data.audioBase64) {
        const audioSrc = `data:${data.mimeType || 'audio/wav'};base64,${data.audioBase64}`;
        const audio = new Audio(audioSrc);
        currentAudio = audio;

        audio.onended = () => {
          currentAudio = null;
          onEnd?.();
        };

        audio.onerror = () => {
          currentAudio = null;
          fallbackBrowserSpeak(spokenText, onEnd);
        };

        await audio.play();
        return;
      }
    }
    // Fallback to browser SpeechSynthesis if API call fails or rate limited
    fallbackBrowserSpeak(spokenText, onEnd);
  } catch (err) {
    console.warn('Gemini TTS failed, falling back to browser speech:', err);
    fallbackBrowserSpeak(spokenText, onEnd);
  }
}

export function stopSpeaking(): void {
  if (currentAudio) {
    try {
      currentAudio.pause();
      currentAudio.currentTime = 0;
    } catch (e) {
      // ignore
    }
    currentAudio = null;
  }
  if (typeof window !== 'undefined' && 'speechSynthesis' in window) {
    try {
      window.speechSynthesis.cancel();
    } catch (e) {
      // ignore
    }
  }
}

function fallbackBrowserSpeak(text: string, onEnd?: () => void): void {
  if (typeof window === 'undefined' || !('speechSynthesis' in window)) {
    onEnd?.();
    return;
  }

  try {
    window.speechSynthesis.cancel();
    const utterance = new SpeechSynthesisUtterance(text);
    utterance.rate = 1.05;
    utterance.pitch = 1.0;

    // Pick a natural English voice if present
    const voices = window.speechSynthesis.getVoices();
    const googleVoice = voices.find(
      (v) => v.name.includes('Google') || v.name.includes('Natural') || v.lang.startsWith('en')
    );
    if (googleVoice) {
      utterance.voice = googleVoice;
    }

    utterance.onend = () => {
      onEnd?.();
    };

    utterance.onerror = () => {
      onEnd?.();
    };

    window.speechSynthesis.speak(utterance);
  } catch (err) {
    console.error('Browser speech error:', err);
    onEnd?.();
  }
}

/**
 * Checks if Speech Recognition is supported in the current browser
 */
export function isSpeechRecognitionSupported(): boolean {
  if (typeof window === 'undefined') return false;
  return Boolean((window as any).SpeechRecognition || (window as any).webkitSpeechRecognition);
}
