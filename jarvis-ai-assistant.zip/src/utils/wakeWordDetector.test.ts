import test from 'node:test';
import assert from 'node:assert/strict';
import { normalizeSpeech, extractWakeWordCommand } from './wakeWordDetector';

test('normalizeSpeech strips punctuation and trims spaces', () => {
  assert.equal(normalizeSpeech('  Hey, Jarvis!! How are you?  '), 'hey jarvis how are you');
  assert.equal(normalizeSpeech('Hello... World???'), 'hello world');
  assert.equal(normalizeSpeech(''), '');
});

test('extractWakeWordCommand detects exact "hey jarvis" wake word', () => {
  const result = extractWakeWordCommand('Hey Jarvis, what is the weather today?');
  assert.equal(result.detected, true);
  assert.equal(result.wakeWordMatched, 'hey jarvis');
  assert.equal(result.command, 'what is the weather today');
  assert.equal(result.isDirectCommand, true);
});

test('extractWakeWordCommand detects single "jarvis" keyword', () => {
  const result = extractWakeWordCommand('Jarvis write me a quick poem');
  assert.equal(result.detected, true);
  assert.equal(result.wakeWordMatched, 'jarvis');
  assert.equal(result.command, 'write me a quick poem');
  assert.equal(result.isDirectCommand, true);
});

test('extractWakeWordCommand handles wake word with no follow-up command yet', () => {
  const result = extractWakeWordCommand('Hey Jarvis!');
  assert.equal(result.detected, true);
  assert.equal(result.command, '');
  assert.equal(result.isDirectCommand, false);
});

test('extractWakeWordCommand returns detected false when no wake word present', () => {
  const result = extractWakeWordCommand('What time is the train leaving?');
  assert.equal(result.detected, false);
  assert.equal(result.wakeWordMatched, null);
  assert.equal(result.command, 'what time is the train leaving');
  assert.equal(result.isDirectCommand, false);
});

test('extractWakeWordCommand supports variations like "hello jarvis"', () => {
  const result = extractWakeWordCommand('Hello Jarvis, explain black holes');
  assert.equal(result.detected, true);
  assert.equal(result.wakeWordMatched, 'hello jarvis');
  assert.equal(result.command, 'explain black holes');
});

test('extractWakeWordCommand detects "hey friday" wake word for Friday AI', () => {
  const result = extractWakeWordCommand('Hey Friday, analyze combat trajectory');
  assert.equal(result.detected, true);
  assert.equal(result.wakeWordMatched, 'hey friday');
  assert.equal(result.command, 'analyze combat trajectory');
  assert.equal(result.isDirectCommand, true);
});

test('extractWakeWordCommand detects "hey edith" wake word for Edith AI', () => {
  const result = extractWakeWordCommand('Hey Edith, scan perimeter drones');
  assert.equal(result.detected, true);
  assert.equal(result.wakeWordMatched, 'hey edith');
  assert.equal(result.command, 'scan perimeter drones');
  assert.equal(result.isDirectCommand, true);
});
