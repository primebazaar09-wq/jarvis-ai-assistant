import React, { useState } from 'react';
import { Check, Copy } from 'lucide-react';

interface MarkdownProps {
  content: string;
}

export const MarkdownRenderer: React.FC<MarkdownProps> = ({ content }) => {
  if (!content) return null;

  // Split into code blocks and normal markdown segments
  const segments = content.split(/(```[\s\S]*?```)/g);

  return (
    <div className="space-y-3 leading-relaxed text-[#e3e3e3] font-normal text-[15px]">
      {segments.map((segment, idx) => {
        if (segment.startsWith('```') && segment.endsWith('```')) {
          return <CodeBlock key={idx} rawCode={segment} />;
        }
        return <FormattedParagraphs key={idx} text={segment} />;
      })}
    </div>
  );
};

const CodeBlock: React.FC<{ rawCode: string }> = ({ rawCode }) => {
  const [copied, setCopied] = useState(false);

  // Extract language and code lines
  const lines = rawCode.slice(3, -3).trim().split('\n');
  let lang = 'code';
  let code = rawCode.slice(3, -3).trim();

  if (lines.length > 0 && /^[a-zA-Z0-9_-]+$/.test(lines[0].trim())) {
    lang = lines[0].trim();
    code = lines.slice(1).join('\n');
  }

  const handleCopy = async () => {
    try {
      await navigator.clipboard.writeText(code);
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    } catch (err) {
      console.error('Failed to copy code', err);
    }
  };

  return (
    <div className="my-4 rounded-xl overflow-hidden border border-[#3c4043] bg-[#1e1f20] font-mono text-xs shadow-sm">
      <div className="flex items-center justify-between px-4 py-2 bg-[#282a2c] border-b border-[#3c4043]/60 text-[#9aa0a6]">
        <span className="font-medium tracking-wide uppercase text-[11px] text-[#c4c7c5]">
          {lang}
        </span>
        <button
          onClick={handleCopy}
          className="flex items-center gap-1.5 px-2.5 py-1 rounded-md text-xs hover:bg-[#3c4043] text-[#c4c7c5] hover:text-white transition-colors"
          title="Copy code"
        >
          {copied ? (
            <>
              <Check className="w-3.5 h-3.5 text-emerald-400" />
              <span className="text-emerald-400">Copied</span>
            </>
          ) : (
            <>
              <Copy className="w-3.5 h-3.5" />
              <span>Copy</span>
            </>
          )}
        </button>
      </div>
      <div className="p-4 overflow-x-auto text-[#e3e3e3] bg-[#131314]/80 text-[13px] leading-relaxed">
        <pre className="font-mono">
          <code>{code}</code>
        </pre>
      </div>
    </div>
  );
};

const FormattedParagraphs: React.FC<{ text: string }> = ({ text }) => {
  const lines = text.split('\n');
  const elements: React.ReactNode[] = [];
  let currentList: { type: 'ul' | 'ol'; items: string[] } | null = null;

  const flushList = () => {
    if (currentList) {
      if (currentList.type === 'ul') {
        elements.push(
          <ul key={`list-${elements.length}`} className="list-disc pl-5 space-y-1.5 my-2">
            {currentList.items.map((it, i) => (
              <li key={i}>{formatInline(it)}</li>
            ))}
          </ul>
        );
      } else {
        elements.push(
          <ol key={`list-${elements.length}`} className="list-decimal pl-5 space-y-1.5 my-2">
            {currentList.items.map((it, i) => (
              <li key={i}>{formatInline(it)}</li>
            ))}
          </ol>
        );
      }
      currentList = null;
    }
  };

  for (let i = 0; i < lines.length; i++) {
    const line = lines[i];
    const trimmed = line.trim();

    // Headers
    if (trimmed.startsWith('### ')) {
      flushList();
      elements.push(
        <h3 key={i} className="text-lg font-semibold text-white pt-2 pb-1">
          {formatInline(trimmed.slice(4))}
        </h3>
      );
      continue;
    }
    if (trimmed.startsWith('## ')) {
      flushList();
      elements.push(
        <h2 key={i} className="text-xl font-semibold text-white pt-3 pb-1">
          {formatInline(trimmed.slice(3))}
        </h2>
      );
      continue;
    }
    if (trimmed.startsWith('# ')) {
      flushList();
      elements.push(
        <h1 key={i} className="text-2xl font-bold text-white pt-3 pb-1">
          {formatInline(trimmed.slice(2))}
        </h1>
      );
      continue;
    }

    // Bullet lists
    if (trimmed.startsWith('* ') || trimmed.startsWith('- ')) {
      if (!currentList || currentList.type !== 'ul') {
        flushList();
        currentList = { type: 'ul', items: [] };
      }
      currentList.items.push(trimmed.slice(2));
      continue;
    }

    // Numbered lists
    const matchNum = trimmed.match(/^(\d+)\.\s+(.*)/);
    if (matchNum) {
      if (!currentList || currentList.type !== 'ol') {
        flushList();
        currentList = { type: 'ol', items: [] };
      }
      currentList.items.push(matchNum[2]);
      continue;
    }

    // Blockquotes
    if (trimmed.startsWith('> ')) {
      flushList();
      elements.push(
        <blockquote
          key={i}
          className="border-l-4 border-[#8ab4f8] pl-3 py-1 text-[#bdc1c6] italic my-2 bg-[#1e1f20]/40 rounded-r"
        >
          {formatInline(trimmed.slice(2))}
        </blockquote>
      );
      continue;
    }

    // Regular line / paragraph break
    if (trimmed === '') {
      flushList();
      continue;
    }

    flushList();
    elements.push(
      <p key={i} className="mb-2 last:mb-0">
        {formatInline(line)}
      </p>
    );
  }

  flushList();

  return <>{elements}</>;
};

function formatInline(text: string): React.ReactNode {
  // Replace inline bold, code, and italics
  const parts = text.split(/(`[^`]+`|\*\*[^*]+\*\*|\*[^*]+\*)/g);

  return parts.map((part, i) => {
    if (part.startsWith('`') && part.endsWith('`') && part.length > 2) {
      return (
        <code
          key={i}
          className="px-1.5 py-0.5 rounded bg-[#282a2c] text-[#a8c7fa] font-mono text-[13px] border border-[#3c4043]/50"
        >
          {part.slice(1, -1)}
        </code>
      );
    }
    if (part.startsWith('**') && part.endsWith('**') && part.length > 4) {
      return (
        <strong key={i} className="font-semibold text-white">
          {part.slice(2, -2)}
        </strong>
      );
    }
    if (part.startsWith('*') && part.endsWith('*') && part.length > 2) {
      return (
        <em key={i} className="italic text-[#c4c7c5]">
          {part.slice(1, -1)}
        </em>
      );
    }
    return part;
  });
}
