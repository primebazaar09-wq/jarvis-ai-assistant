import React, { useState, useEffect, useRef, useCallback } from 'react';
import { Header } from './components/Header';
import { Sidebar } from './components/Sidebar';
import { ChatView } from './components/ChatView';
import { InputBar } from './components/InputBar';
import { JarvisLiveVoiceOverlay } from './components/JarvisLiveVoiceOverlay';
import { SettingsModal } from './components/SettingsModal';
import { StarkEcosystemModal } from './components/StarkEcosystemModal';
import {
  ChatMessage,
  ChatSession,
  VoiceSettings,
  MessageAttachment,
  AISystemType,
  AI_SYSTEMS,
} from './types';
import { DEFAULT_WAKE_WORDS } from './utils/wakeWordDetector';
import { useJarvisVoice } from './hooks/useJarvisVoice';
import { speakText, stopSpeaking } from './utils/speechManager';

const STORAGE_KEY_SESSIONS = 'gemini_jarvis_sessions_v1';
const STORAGE_KEY_SETTINGS = 'gemini_jarvis_settings_v1';

const DEFAULT_SETTINGS: VoiceSettings = {
  wakeWordEnabled: true,
  wakeWords: DEFAULT_WAKE_WORDS,
  autoSpeakResponse: false,
  voiceName: 'Zephyr',
  speechRate: 1.0,
  continuousConversation: false,
  activeSystem: 'JARVIS',
};

function createInitialSession(system: AISystemType = 'JARVIS'): ChatSession {
  return {
    id: `session_${Date.now()}`,
    title: 'New chat',
    createdAt: Date.now(),
    updatedAt: Date.now(),
    messages: [],
    model: 'gemini-3.5-flash',
    aiSystem: system,
  };
}

export function App() {
  // Session storage
  const [sessions, setSessions] = useState<ChatSession[]>(() => {
    try {
      const saved = localStorage.getItem(STORAGE_KEY_SESSIONS);
      if (saved) {
        const parsed = JSON.parse(saved);
        if (Array.isArray(parsed) && parsed.length > 0) return parsed;
      }
    } catch (e) {
      console.error(e);
    }
    return [createInitialSession()];
  });

  const [activeSessionId, setActiveSessionId] = useState<string>(
    () => sessions[0]?.id || ''
  );

  // Settings
  const [settings, setSettings] = useState<VoiceSettings>(() => {
    try {
      const saved = localStorage.getItem(STORAGE_KEY_SETTINGS);
      if (saved) return { ...DEFAULT_SETTINGS, ...JSON.parse(saved) };
    } catch (e) {
      console.error(e);
    }
    return DEFAULT_SETTINGS;
  });

  // Active AI System (JARVIS, FRIDAY, EDITH)
  const [activeAISystem, setActiveAISystem] = useState<AISystemType>(
    () => settings.activeSystem || 'JARVIS'
  );

  // UI state
  const [sidebarOpen, setSidebarOpen] = useState(() => {
    if (typeof window !== 'undefined') {
      return window.innerWidth >= 768;
    }
    return true;
  });
  const [liveVoiceOpen, setLiveVoiceOpen] = useState(false);
  const [settingsOpen, setSettingsOpen] = useState(false);
  const [starkEcosystemOpen, setStarkEcosystemOpen] = useState(false);
  const [selectedModel, setSelectedModel] = useState<
    'gemini-3.5-flash' | 'gemini-3.8-flash' | 'gemini-4-argon'
  >('gemini-3.5-flash');

  // Input & Messaging state
  const [prompt, setPrompt] = useState('');
  const [attachment, setAttachment] = useState<MessageAttachment | null>(null);
  const [isLoading, setIsLoading] = useState(false);
  const [activeSpeakingMessageId, setActiveSpeakingMessageId] = useState<
    string | null
  >(null);
  const [lastResponseText, setLastResponseText] = useState('');

  const abortControllerRef = useRef<AbortController | null>(null);

  // Sync sessions to localStorage
  useEffect(() => {
    try {
      localStorage.setItem(STORAGE_KEY_SESSIONS, JSON.stringify(sessions));
    } catch (e) {
      console.error(e);
    }
  }, [sessions]);

  // Sync settings to localStorage
  useEffect(() => {
    try {
      localStorage.setItem(STORAGE_KEY_SETTINGS, JSON.stringify(settings));
    } catch (e) {
      console.error(e);
    }
  }, [settings]);

  const activeSessionIdRef = useRef(activeSessionId);
  activeSessionIdRef.current = activeSessionId;

  // Active session helper
  const activeSession =
    sessions.find((s) => s.id === activeSessionId) || sessions[0];

  // AI System Selection Handler
  const handleSelectAISystem = useCallback((sys: AISystemType) => {
    setActiveAISystem(sys);
    const sysData = AI_SYSTEMS[sys];
    setSettings((prev) => ({
      ...prev,
      activeSystem: sys,
      voiceName: sysData.defaultVoice,
      wakeWords: Array.from(new Set([...sysData.wakeWords, ...prev.wakeWords])),
    }));
  }, []);

  // Send message handler (supports text, attachments, streaming SSE)
  const handleSendMessage = useCallback(
    async (textToSend?: string, attachedToSend?: MessageAttachment | null) => {
      const content = (textToSend ?? prompt).trim();
      const currentAttachment = attachedToSend ?? attachment;

      if (!content && !currentAttachment) return;
      if (isLoading) return;

      stopSpeaking();
      setActiveSpeakingMessageId(null);

      const currentActiveId = activeSessionIdRef.current;
      const userMessageId = `msg_user_${Date.now()}`;
      const modelMessageId = `msg_model_${Date.now()}`;

      const newUserMessage: ChatMessage = {
        id: userMessageId,
        role: 'user',
        text: content,
        timestamp: Date.now(),
        attachment: currentAttachment || undefined,
      };

      const newModelMessage: ChatMessage = {
        id: modelMessageId,
        role: 'model',
        text: '',
        timestamp: Date.now(),
        isStreaming: true,
        aiSystem: activeAISystem,
      };

      // Auto update title on first message
      const currSession =
        sessions.find((s) => s.id === currentActiveId) || sessions[0];
      const isFirstMessage = currSession.messages.length === 0;
      const newTitle = isFirstMessage
        ? content.slice(0, 32) || 'Image Analysis'
        : currSession.title;

      // Update state with user message & placeholder model message
      setSessions((prev) =>
        prev.map((s) => {
          if (s.id === currentActiveId) {
            return {
              ...s,
              title: newTitle,
              updatedAt: Date.now(),
              aiSystem: activeAISystem,
              messages: [...s.messages, newUserMessage, newModelMessage],
            };
          }
          return s;
        })
      );

      setPrompt('');
      setAttachment(null);
      setIsLoading(true);

      const abortController = new AbortController();
      abortControllerRef.current = abortController;

      let accumulatedText = '';
      const startTime = Date.now();

      try {
        // Send request to server-side Gemini SSE endpoint
        const response = await fetch('/api/gemini/chat', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          signal: abortController.signal,
          body: JSON.stringify({
            prompt: content,
            attachment: currentAttachment,
            model: selectedModel,
            aiSystem: activeAISystem,
            thinkingLevel:
              selectedModel === 'gemini-4-argon' ? 'HIGH' : undefined,
            stream: true,
            history: currSession.messages.map((m) => ({
              role: m.role,
              text: m.text,
            })),
          }),
        });

        if (!response.ok) {
          const errData = await response.json().catch(() => ({}));
          throw new Error(
            errData.error || `Server responded with ${response.status}`
          );
        }

        const reader = response.body?.getReader();
        const decoder = new TextDecoder();

        if (reader) {
          let done = false;
          while (!done) {
            const { value, done: streamDone } = await reader.read();
            done = streamDone;
            if (value) {
              const chunk = decoder.decode(value, { stream: true });
              const lines = chunk.split('\n');
              for (const line of lines) {
                if (line.startsWith('data: ')) {
                  try {
                    const data = JSON.parse(line.slice(6));
                    if (data.text) {
                      accumulatedText += data.text;
                      setSessions((prev) =>
                        prev.map((s) => {
                          if (s.id === currentActiveId) {
                            return {
                              ...s,
                              messages: s.messages.map((m) =>
                                m.id === modelMessageId
                                  ? { ...m, text: accumulatedText }
                                  : m
                              ),
                            };
                          }
                          return s;
                        })
                      );
                    } else if (data.error && !accumulatedText) {
                      throw new Error(data.error);
                    }
                  } catch (e: any) {
                    if (e.message && e.message !== 'Unexpected end of JSON input') {
                      throw e;
                    }
                  }
                }
              }
            }
          }
        }

        // Finalize model message
        const duration = Date.now() - startTime;
        setLastResponseText(accumulatedText);

        setSessions((prev) =>
          prev.map((s) => {
            if (s.id === currentActiveId) {
              return {
                ...s,
                messages: s.messages.map((m) =>
                  m.id === modelMessageId
                    ? {
                        ...m,
                        text: accumulatedText || 'I am ready to assist you.',
                        isStreaming: false,
                        thoughtDurationMs: duration,
                      }
                    : m
                ),
              };
            }
            return s;
          })
        );

        // Auto-speak response if enabled or in Live Voice mode
        if ((settings.autoSpeakResponse || liveVoiceOpen) && accumulatedText) {
          setActiveSpeakingMessageId(modelMessageId);
          speakText(
            accumulatedText,
            settings.voiceName,
            undefined,
            () => {
              setActiveSpeakingMessageId(null);
              // Continuous hands-free conversation support
              if (settings.continuousConversation && liveVoiceOpen) {
                voiceControls.triggerWakeWord();
              }
            }
          );
        }
      } catch (err: any) {
        if (err.name === 'AbortError') {
          console.debug('Generation aborted');
        } else {
          console.error('Chat error:', err);
          setSessions((prev) =>
            prev.map((s) => {
              if (s.id === currentActiveId) {
                return {
                  ...s,
                  messages: s.messages.map((m) =>
                    m.id === modelMessageId
                      ? {
                          ...m,
                          isStreaming: false,
                          error:
                            err.message ||
                            'Failed to receive response from Jarvis. Please ensure your API key is active.',
                        }
                      : m
                  ),
                };
              }
              return s;
            })
          );
        }
      } finally {
        setIsLoading(false);
        abortControllerRef.current = null;
      }
    },
    [
      prompt,
      attachment,
      isLoading,
      sessions,
      selectedModel,
      activeAISystem,
      settings,
      liveVoiceOpen,
    ]
  );

  // Hook for voice listening & wake words
  const voiceControls = useJarvisVoice({
    wakeWords: settings.wakeWords,
    enabled: settings.wakeWordEnabled,
    autoSpeak: settings.autoSpeakResponse,
    onCommand: (detectedCommand) => {
      handleSendMessage(detectedCommand, null);
    },
  });

  // Stop active generation
  const handleStop = () => {
    if (abortControllerRef.current) {
      abortControllerRef.current.abort();
      setIsLoading(false);
    }
  };

  // Speak a message aloud
  const handleSpeakMessage = (id: string, text: string) => {
    stopSpeaking();
    setActiveSpeakingMessageId(id);
    speakText(
      text,
      settings.voiceName,
      undefined,
      () => setActiveSpeakingMessageId(null)
    );
  };

  // Stop speaking
  const handleStopSpeaking = () => {
    stopSpeaking();
    setActiveSpeakingMessageId(null);
  };

  // Create new session
  const handleNewChat = () => {
    stopSpeaking();
    setActiveSpeakingMessageId(null);
    const newSession = createInitialSession(activeAISystem);
    setSessions((prev) => [newSession, ...prev]);
    setActiveSessionId(newSession.id);
    setPrompt('');
    setAttachment(null);
  };

  // Delete session
  const handleDeleteSession = (id: string) => {
    setSessions((prev) => {
      const remaining = prev.filter((s) => s.id !== id);
      if (remaining.length === 0) {
        const fresh = createInitialSession(activeAISystem);
        setActiveSessionId(fresh.id);
        return [fresh];
      }
      if (activeSessionId === id) {
        setActiveSessionId(remaining[0].id);
      }
      return remaining;
    });
  };

  // Pin session
  const handleTogglePinSession = (id: string) => {
    setSessions((prev) =>
      prev.map((s) => (s.id === id ? { ...s, pinned: !s.pinned } : s))
    );
  };

  // Clear Conversation of currently active session without deleting the session
  const handleClearActiveConversation = useCallback(() => {
    stopSpeaking();
    setActiveSpeakingMessageId(null);
    const currentActiveId = activeSessionIdRef.current;
    setSessions((prev) =>
      prev.map((s) => {
        if (s.id === currentActiveId) {
          return {
            ...s,
            title: 'New chat',
            messages: [],
            updatedAt: Date.now(),
          };
        }
        return s;
      })
    );
    setPrompt('');
    setAttachment(null);
  }, []);

  // Regenerate latest response
  const handleRegenerate = () => {
    const msgs = activeSession.messages;
    if (msgs.length < 2) return;
    const lastUserMsg = [...msgs].reverse().find((m) => m.role === 'user');
    if (lastUserMsg) {
      setSessions((prev) =>
        prev.map((s) => {
          if (s.id === activeSession.id) {
            return {
              ...s,
              messages: s.messages.slice(0, -1),
            };
          }
          return s;
        })
      );
      handleSendMessage(lastUserMsg.text, lastUserMsg.attachment || null);
    }
  };

  // Simulated wake word test
  const handleSimulateWakeWord = () => {
    voiceControls.triggerWakeWord(
      `Hey ${activeAISystem === 'EDITH' ? 'Edith' : activeAISystem === 'FRIDAY' ? 'Friday' : 'Jarvis'}, compare the capabilities of JARVIS, FRIDAY, and E.D.I.T.H.`
    );
  };

  return (
    <div className="flex h-screen w-screen overflow-hidden bg-[#131314] text-[#e3e3e3] font-['Google_Sans_Text',sans-serif]">
      {/* Left Sidebar */}
      <Sidebar
        isOpen={sidebarOpen}
        onToggle={() => setSidebarOpen(!sidebarOpen)}
        sessions={sessions}
        activeSessionId={activeSessionId}
        onSelectSession={(id) => {
          stopSpeaking();
          setActiveSessionId(id);
        }}
        onNewChat={handleNewChat}
        onDeleteSession={handleDeleteSession}
        onTogglePinSession={handleTogglePinSession}
        onOpenSettings={() => setSettingsOpen(true)}
        wakeWordActive={settings.wakeWordEnabled}
        onToggleWakeWord={() =>
          setSettings((prev) => ({
            ...prev,
            wakeWordEnabled: !prev.wakeWordEnabled,
          }))
        }
        onOpenLiveVoice={() => setLiveVoiceOpen(true)}
        onClearConversation={handleClearActiveConversation}
        onOpenStarkEcosystem={() => setStarkEcosystemOpen(true)}
        activeAISystem={activeAISystem}
      />

      {/* Main Content Area */}
      <div className="flex-1 flex flex-col h-full overflow-hidden bg-[#131314] relative">
        {/* Top Header */}
        <Header
          onToggleSidebar={() => setSidebarOpen(!sidebarOpen)}
          selectedModel={selectedModel}
          onSelectModel={setSelectedModel}
          wakeWordActive={settings.wakeWordEnabled}
          onToggleWakeWord={() =>
            setSettings((prev) => ({
              ...prev,
              wakeWordEnabled: !prev.wakeWordEnabled,
            }))
          }
          onOpenLiveVoice={() => setLiveVoiceOpen(true)}
          onOpenSettings={() => setSettingsOpen(true)}
          isAwake={voiceControls.isAwake}
          onSimulateWakeWord={handleSimulateWakeWord}
          autoSpeak={settings.autoSpeakResponse}
          onToggleAutoSpeak={() =>
            setSettings((prev) => ({
              ...prev,
              autoSpeakResponse: !prev.autoSpeakResponse,
            }))
          }
          activeAISystem={activeAISystem}
          onSelectAISystem={handleSelectAISystem}
          onOpenStarkEcosystem={() => setStarkEcosystemOpen(true)}
          hasMessages={activeSession.messages.length > 0}
          onClearConversation={handleClearActiveConversation}
        />

        {/* Chat / Scroll View */}
        <ChatView
          messages={activeSession.messages}
          isLoading={isLoading}
          onSelectPrompt={(p) => handleSendMessage(p, null)}
          onSpeakMessage={handleSpeakMessage}
          onStopSpeaking={handleStopSpeaking}
          activeSpeakingMessageId={activeSpeakingMessageId}
          onRegenerate={handleRegenerate}
          onSimulateWakeWord={handleSimulateWakeWord}
          activeAISystem={activeAISystem}
          onOpenStarkEcosystem={() => setStarkEcosystemOpen(true)}
        />

        {/* Bottom Floating Pill Input Bar */}
        <InputBar
          prompt={prompt}
          onChangePrompt={setPrompt}
          onSubmit={() => handleSendMessage()}
          isLoading={isLoading}
          onStop={handleStop}
          attachment={attachment}
          onSelectAttachment={setAttachment}
          isListening={voiceControls.isListening}
          isAwake={voiceControls.isAwake}
          audioLevel={voiceControls.audioLevel}
          onToggleMic={() => {
            if (voiceControls.isAwake) {
              voiceControls.dismissAwake();
            } else {
              voiceControls.startDirectListening();
            }
          }}
          onOpenLiveVoice={() => setLiveVoiceOpen(true)}
        />
      </div>

      {/* Flagship Live Voice HUD Overlay */}
      <JarvisLiveVoiceOverlay
        isOpen={liveVoiceOpen}
        onClose={() => setLiveVoiceOpen(false)}
        isListening={voiceControls.isListening}
        isAwake={voiceControls.isAwake}
        transcript={voiceControls.transcript}
        interimText={voiceControls.interimText}
        audioLevel={voiceControls.audioLevel}
        audioSpectrum={voiceControls.audioSpectrum}
        isSpeaking={Boolean(activeSpeakingMessageId)}
        lastResponseText={lastResponseText}
        onSimulateCommand={(cmd) => {
          voiceControls.triggerWakeWord(cmd);
        }}
        onToggleMic={() => {
          setSettings((prev) => ({
            ...prev,
            wakeWordEnabled: !prev.wakeWordEnabled,
          }));
        }}
        voiceName={settings.voiceName}
        onChangeVoice={(v) => setSettings((prev) => ({ ...prev, voiceName: v }))}
        onInterruptSpeech={handleStopSpeaking}
      />

      {/* Stark AI Ecosystem Modal (JARVIS, FRIDAY, EDITH) */}
      <StarkEcosystemModal
        isOpen={starkEcosystemOpen}
        onClose={() => setStarkEcosystemOpen(false)}
        activeSystem={activeAISystem}
        onSelectSystem={handleSelectAISystem}
        onAskAboutSystem={(question) => handleSendMessage(question, null)}
      />

      {/* Settings Modal */}
      <SettingsModal
        isOpen={settingsOpen}
        onClose={() => setSettingsOpen(false)}
        settings={settings}
        onUpdateSettings={(newSettings) =>
          setSettings((prev) => ({ ...prev, ...newSettings }))
        }
      />
    </div>
  );
}

export default App;
